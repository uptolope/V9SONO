"use client";

import Link from "next/link";
import { useEffect, useState, useRef } from "react";
import { Header } from "@/components/layout/header";
import { ExamSimulator } from "@/components/app/exam-simulator";
import { FlashcardViewer } from "@/components/app/flashcard-viewer";
import { DEMO_QUESTIONS } from "@/lib/demo/exam-data";
import { DEMO_FLASHCARDS } from "@/lib/demo/flashcard-data";

/* ── Shared intersection hook ──────────────────────────────────────── */
function useVisible(threshold = 0.1) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const ob = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold });
    if (ref.current) ob.observe(ref.current);
    return () => ob.disconnect();
  }, []);
  return { ref, visible };
}

/* ── Hero ──────────────────────────────────────────────────────────── */
function Hero() {
  const [visible, setVisible] = useState(false);
  useEffect(() => { const t = setTimeout(() => setVisible(true), 200); return () => clearTimeout(t); }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden page-emerge">
      <div className="sono-atmosphere" />
      <div className="sono-scan" />
      <div className="relative z-10 max-w-5xl mx-auto px-6 pt-32 pb-20">

        {/* Credential gate — first thing they read */}
        <div className={`text-center mb-8 transition-all duration-700 delay-100 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div className="inline-flex flex-wrap items-center justify-center gap-x-4 gap-y-1 px-5 py-2.5 border border-[#c85b3a]/20 bg-[#c85b3a]/[0.04]">
            {["RDMS", "RDCS", "RVT", "RMSKS"].map((c) => (
              <span key={c} className="meta text-[10px] text-[#c85b3a]">{c}</span>
            ))}
            <span className="meta text-[10px] text-[#4a453f] normal-case tracking-wide" style={{ textTransform: "none", letterSpacing: "0.04em" }}>
              — none of these credentials are possible without passing the SPI exam first
            </span>
          </div>
        </div>

        {/* Headline */}
        <div className={`text-center mb-6 transition-all duration-700 delay-200 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <h1 className="display-display text-6xl sm:text-7xl md:text-[5.5rem] leading-[1.04]">
            The SPI exam is the<br />
            <span className="text-[#c85b3a]">first gate to your career.</span>
          </h1>
        </div>

        {/* Stakes subheadline */}
        <div className={`text-center mb-10 transition-all duration-700 delay-300 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <p className="body-readable text-[1.05rem] max-w-2xl mx-auto text-[#b8b0a4]">
            Most students don't fail the SPI because they didn't study. They fail because they studied the wrong material —
            broad textbooks that don't match what ARDMS actually tests. Retaking means more fees,
            more delays, and a pushed-back start on your specialty credential.
            SonoPrep closes that gap: 200+ flashcards, a 170-question domain-weighted simulator,
            and 50 Physics Pearls — all written by an RDMS instructor who taught this curriculum
            at Houston International Cardiotech Ultrasound School.
          </p>
        </div>

        {/* CTAs */}
        <div className={`flex flex-col sm:flex-row items-center justify-center gap-4 mb-6 transition-all duration-700 delay-400 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <Link href="#demo" className="tactile-button px-8 py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all duration-300 text-base font-medium">
            Start 2-Minute SPI Check →
          </Link>
          <Link href="/products" className="tactile-button px-8 py-4 border border-[#f0ebe4]/15 text-[#b8b0a4] hover:text-[#f0ebe4] hover:border-[#f0ebe4]/25 transition-all duration-300 text-base">
            See Pricing
          </Link>
        </div>

        {/* Micro-commitment strip */}
        <div className={`flex items-center justify-center gap-4 mb-14 transition-all duration-700 delay-450 ${visible ? "opacity-100" : "opacity-0"}`}>
          <span className="meta text-[9px] text-[#3a3530]">Takes 2 minutes</span>
          <span className="text-[#2e2b27]">·</span>
          <span className="meta text-[9px] text-[#3a3530]">No signup required</span>
          <span className="text-[#2e2b27]">·</span>
          <span className="meta text-[9px] text-[#3a3530]">Instant domain feedback</span>
        </div>

        {/* Stats */}
        <div className={`grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-xl mx-auto transition-all duration-700 delay-500 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          {[
            { n: "200+", label: "Flashcards" },
            { n: "170",  label: "Domain-Weighted Questions" },
            { n: "50",   label: "Physics Pearls" },
            { n: "$9",   label: "Starting Price" },
          ].map(({ n, label }) => (
            <div key={label} className="text-center border border-[#f0ebe4]/6 py-4 px-2">
              <div className="display-serif text-3xl font-bold text-white">{n}</div>
              <div className="meta text-[10px] mt-1 text-[#4a453f]">{label}</div>
            </div>
          ))}
        </div>

        {/* Quiet confidence line — now earned with specificity */}
        <div className={`text-center mt-8 transition-all duration-700 delay-600 ${visible ? "opacity-100" : "opacity-0"}`}>
          <p className="display-serif text-lg text-[#b8b0a4] italic">You don't need more material. You need the right material.</p>
          <p className="body-readable text-[#6b6359] text-xs mt-2 max-w-lg mx-auto">
            Not 1,000 random questions. Not recycled quiz banks. A system built around how the SPI is actually tested — 
            mapped to the 6 ARDMS domains, weighted to match the real exam.
          </p>
        </div>
      </div>
    </section>
  );
}

/* ── Decision Moment — fork in the road ───────────────────────────── */
function DecisionMoment() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-20 px-6 border-t border-[#f0ebe4]/5 bg-[#c85b3a]/[0.02]">
      <div className="max-w-3xl mx-auto text-center">
        <div className={`transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">THE CHOICE IN FRONT OF YOU</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-4 font-semibold tracking-tight leading-snug">
            If your SPI is coming up, you have two paths.
          </h2>
        </div>

        <div className={`mt-10 grid md:grid-cols-2 gap-5 text-left transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          {/* Path A — wrong one */}
          <div className="p-6 border border-[#f0ebe4]/8 opacity-60">
            <div className="meta text-[9px] text-[#4a453f] mb-3">PATH A</div>
            <h3 className="display-serif text-lg font-semibold text-[#f0ebe4] mb-3 leading-snug">
              Study everything and hope it's enough.
            </h3>
            <p className="body-small text-[#6b6359] text-sm leading-relaxed">
              Read the textbook cover to cover. Do random practice questions.
              Walk in and find out which topics the exam actually weighted heavily.
              If that doesn't work — pay the retake fee and do it again.
            </p>
          </div>

          {/* Path B — right one */}
          <div className="p-6 border border-[#c85b3a]/25 bg-[#c85b3a]/[0.04] relative">
            <div className="absolute top-0 left-0 bg-[#c85b3a] px-3 py-1 meta text-[9px] text-white">WHAT SONOPREP IS BUILT FOR</div>
            <div className="meta text-[9px] text-[#c85b3a] mb-3 mt-5">PATH B</div>
            <h3 className="display-serif text-lg font-semibold text-[#f0ebe4] mb-3 leading-snug">
              Focus on exactly what ARDMS tests. Walk in prepared.
            </h3>
            <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">
              Practice with 170 questions weighted to the real exam's 6 domains.
              See exactly where you're losing points before it costs you.
              Know your weak spots while there's still time to fix them.
            </p>
          </div>
        </div>

        <div className={`mt-10 transition-all duration-700 delay-300 ${visible ? "opacity-100" : "opacity-0"}`}>
          <Link href="#demo" className="tactile-button px-8 py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all duration-300 inline-block meta text-[11px]">
            START WITH THE FREE DEMO →
          </Link>
          <p className="meta text-[9px] text-[#3a3530] mt-3">No account · 2 minutes · instant domain feedback</p>
        </div>
      </div>
    </section>
  );
}

/* ── Who is this for ───────────────────────────────────────────────── */
function WhoIsThisFor() {
  const { ref, visible } = useVisible();

  const personas = [
    {
      tag: "EXAM IN THE NEXT 2–4 WEEKS",
      heading: "Most students don't realize what they're weak on until they lose points for it.",
      body: "Retaking the SPI isn't just inconvenient — it delays every specialty credential you're working toward. SonoPrep's domain-weighted simulator shows you exactly where you're weak while there's still time to fix it.",
      cta: "Start with the Bundle →",
      href: "/products",
    },
    {
      tag: "CURRENTLY IN A SONO PROGRAM",
      heading: "Your program covers the procedures. SonoPrep covers the physics.",
      body: "Most clinical programs don't spend enough time on physics principles — which is exactly what the SPI tests. Our 50 Physics Pearls and 200+ flashcards fill that gap without requiring you to re-read a textbook.",
      cta: "Try the Demo Free →",
      href: "#demo",
    },
    {
      tag: "ALREADY FAILED ONCE",
      heading: "The problem wasn't effort — it was coverage.",
      body: "The SPI tests 6 specific ARDMS domains at specific weightings. If you didn't know where each question was coming from, you couldn't prioritize. Our domain analytics show you exactly where you lost points so your second attempt is targeted, not just harder.",
      cta: "See the Exam Simulator →",
      href: "/products",
    },
  ];

  return (
    <section ref={ref} className="py-24 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-5xl mx-auto">
        <div className={`mb-14 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">WHO THIS IS FOR</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-3 font-semibold tracking-tight max-w-lg">
            If any of these sound like you, you're in the right place.
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-5">
          {personas.map(({ tag, heading, body, cta, href }, i) => (
            <div
              key={tag}
              className="depth-border corner-arch p-6 tactile-card flex flex-col"
              style={{ transitionDelay: visible ? `${i * 80}ms` : "0ms", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.6s, transform 0.6s" }}
            >
              <div className="meta text-[9px] text-[#c85b3a] mb-4">{tag}</div>
              <h3 className="display-serif text-base font-semibold text-[#f0ebe4] mb-3 leading-snug">{heading}</h3>
              <p className="body-small text-[#b8b0a4] text-sm leading-relaxed flex-grow mb-5">{body}</p>
              <Link href={href} className="meta text-[10px] text-[#6b6359] hover:text-[#c85b3a] transition-colors">
                {cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Moment of Realization — internal tension before CTA ──────────── */
function MomentOfRealization() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-20 px-6 border-t border-[#f0ebe4]/5 bg-[#0a0c10]">
      <div className="max-w-3xl mx-auto text-center">

        <div className={`transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">WHY MOST STUDENTS FAIL</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-4 font-semibold tracking-tight leading-snug">
            It's not that they didn't study.<br />
            <span className="text-[#c85b3a]">It's that they didn't know which domains would cost them.</span>
          </h2>
        </div>

        <div className={`mt-10 space-y-4 text-left max-w-xl mx-auto transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          {[
            {
              label: "The SPI doesn't test evenly.",
              body: "Six domains. Different weightings. Most students prep like every topic matters equally. It doesn't.",
            },
            {
              label: "Blind spots don't show up until test day.",
              body: "You can feel prepared and still fail — because you never identified which specific domains you were actually weak in.",
            },
            {
              label: "Broad studying creates false confidence.",
              body: "Reading a textbook cover to cover feels thorough. But the SPI tests how questions are framed, not just what you know. That gap is where points disappear.",
            },
          ].map(({ label, body }, i) => (
            <div
              key={label}
              className="flex gap-4 p-5 border border-[#f0ebe4]/6"
              style={{ transitionDelay: visible ? `${i * 80}ms` : "0ms", opacity: visible ? 1 : 0, transition: "opacity 0.6s" }}
            >
              <span className="text-[#c85b3a] text-sm font-bold shrink-0 mt-0.5">→</span>
              <div>
                <p className="display-serif text-sm font-semibold text-[#f0ebe4] mb-1">{label}</p>
                <p className="body-small text-[#6b6359] text-sm leading-relaxed">{body}</p>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-10 transition-all duration-700 delay-350 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <p className="display-serif text-base text-[#b8b0a4] mb-6 italic">
            The question isn't whether you studied enough. It's whether you know where you'd lose points today.
          </p>
          <Link href="#demo" className="tactile-button px-8 py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all duration-300 inline-block meta text-[11px]">
            FIND OUT WHERE YOU STAND — FREE →
          </Link>
          <p className="meta text-[9px] text-[#3a3530] mt-3">2 minutes · no account · instant domain breakdown</p>
        </div>
      </div>
    </section>
  );
}

/* ── Demo section ──────────────────────────────────────────────────── */
function DemoSection() {
  const [activeTab, setActiveTab]       = useState<"exam" | "flashcards">("exam");
  const [demoComplete, setDemoComplete] = useState(false);
  const [email, setEmail]               = useState("");
  const [submitted, setSubmitted]       = useState(false);
  const { ref, visible }                = useVisible();

  useEffect(() => {
    if (!visible) return;
    const t = setTimeout(() => setDemoComplete(true), 30000);
    return () => clearTimeout(t);
  }, [visible]);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    try { localStorage.setItem("sonoprep_lead_email", email); } catch {}
    setSubmitted(true);
  };

  return (
    <section id="demo" ref={ref} className="py-24 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-4xl mx-auto">

        <div className={`text-center mb-8 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">TRY BEFORE YOU BUY</span>
          <h2 className="display-serif text-4xl sm:text-5xl mt-3 font-semibold tracking-tight">
            Find out what you'd get wrong if you took the SPI today.
          </h2>
          <p className="body-readable text-[#b8b0a4] mt-4 max-w-xl mx-auto">
            This is the actual exam simulator. The full version has 170 ARDMS domain-weighted questions
            with detailed clinical rationales and per-domain performance tracking.
          </p>
        </div>

        {/* Micro-commitment strip — friction killer */}
        <div className={`flex items-center justify-center gap-4 mb-8 transition-all duration-700 delay-100 ${visible ? "opacity-100" : "opacity-0"}`}>
          <span className="meta text-[9px] text-[#3a3530]">Takes 2 minutes</span>
          <span className="text-[#2e2b27]">·</span>
          <span className="meta text-[9px] text-[#3a3530]">No signup required</span>
          <span className="text-[#2e2b27]">·</span>
          <span className="meta text-[9px] text-[#3a3530]">Instant feedback by domain</span>
        </div>

        {/* Tabs */}
        <div className={`flex border-b border-[#f0ebe4]/10 mb-8 transition-all duration-700 delay-150 ${visible ? "opacity-100" : "opacity-0"}`}>
          <button onClick={() => setActiveTab("exam")} className={`px-8 py-3 meta transition-all ${activeTab === "exam" ? "text-[#c85b3a] border-b border-[#c85b3a]" : "text-[#6b6359] hover:text-[#b8b0a4]"}`}>
            Exam Simulator (All 6 Domains)
          </button>
          <button onClick={() => setActiveTab("flashcards")} className={`px-8 py-3 meta transition-all ${activeTab === "flashcards" ? "text-[#c85b3a] border-b border-[#c85b3a]" : "text-[#6b6359] hover:text-[#b8b0a4]"}`}>
            Flashcards
          </button>
        </div>

        <div className={`transition-all duration-700 delay-200 ${visible ? "opacity-100" : "opacity-0"}`}>
          {activeTab === "exam"
            ? <ExamSimulator questions={DEMO_QUESTIONS.slice(0, 5)} />
            : <FlashcardViewer cards={DEMO_FLASHCARDS} />
          }
        </div>

        {/* Email capture after 30s */}
        {demoComplete && !submitted && (
          <div className="mt-10 border border-[#c85b3a]/30 bg-[#c85b3a]/5 p-6">
            <p className="display-serif text-xl font-semibold text-[#f0ebe4] mb-1">
              Want the full exam domain breakdown?
            </p>
            <p className="body-small text-[#b8b0a4] text-sm mb-5">
              We'll send you a free study guide covering the 6 ARDMS SPI domains and which question types
              most students miss. No spam. Unsubscribe anytime.
            </p>
            <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
                className="flex-grow px-4 py-3 bg-[#0a0c10] border border-[#f0ebe4]/15 text-[#f0ebe4] placeholder:text-[#4a453f] text-sm focus:outline-none focus:border-[#c85b3a]/50"
              />
              <button type="submit" className="tactile-button px-6 py-3 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all text-sm meta whitespace-nowrap">
                SEND THE GUIDE →
              </button>
            </form>
            <p className="meta text-[9px] text-[#3a3530] mt-3">Or skip this and <Link href="/products" className="text-[#6b6359] hover:text-[#c85b3a] transition-colors">go straight to products →</Link></p>
          </div>
        )}

        {submitted && (
          <div className="mt-10 border border-[#f0ebe4]/10 p-6 text-center">
            <p className="display-serif text-lg font-semibold text-[#f0ebe4] mb-2">Check your inbox.</p>
            <p className="body-small text-[#b8b0a4] text-sm mb-5">
              The SPI domain breakdown is on its way. When you're ready for the full prep system:
            </p>
            <Link href="/products" className="tactile-button px-6 py-3 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all text-sm meta inline-block">
              GET FULL ACCESS →
            </Link>
          </div>
        )}

        {!demoComplete && (
          <div className={`mt-10 flex flex-col sm:flex-row items-center justify-between gap-6 pt-8 border-t border-[#f0ebe4]/5 transition-all duration-700 delay-400 ${visible ? "opacity-100" : "opacity-0"}`}>
            <div>
              <p className="display-serif text-base font-semibold text-[#f0ebe4] mb-1">Ready for the full 170-question exam?</p>
              <p className="meta text-[10px] text-[#4a453f]">90-day access · 14-day refund policy · instant unlock</p>
            </div>
            <Link href="/products" className="tactile-button px-6 py-3 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all text-sm meta shrink-0">
              GET FULL ACCESS →
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}

/* ── What This Is NOT — removes confusion & false expectations ─────── */
function WhatThisIsNot() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-20 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-3xl mx-auto">
        <div className={`transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">SET THE RIGHT EXPECTATION</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-4 font-semibold tracking-tight">
            What SonoPrep is not.
          </h2>
          <p className="body-readable text-[#6b6359] mt-3 text-sm">
            Most buying hesitation comes from not knowing exactly what you're getting. Here's the honest version.
          </p>
        </div>

        <div className={`mt-10 grid md:grid-cols-3 gap-4 transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          {[
            {
              not: "Not a textbook.",
              is: "It's structured SPI prep based on how the exam is actually weighted — not everything the field covers.",
            },
            {
              not: "Not hundreds of random questions.",
              is: "It's 170 ARDMS domain-weighted questions written by an instructor who has taught this content in a real classroom.",
            },
            {
              not: "Not a subscription.",
              is: "One payment. 90-day access. No recurring charges. The bundle is $99 and covers everything.",
            },
          ].map(({ not, is }, i) => (
            <div
              key={not}
              className="depth-border p-5"
              style={{ transitionDelay: visible ? `${i * 80}ms` : "0ms", opacity: visible ? 1 : 0, transition: "opacity 0.6s" }}
            >
              <p className="meta text-[10px] text-[#c85b3a] mb-2 line-through">{not}</p>
              <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">{is}</p>
            </div>
          ))}
        </div>

        {/* Kill the hidden objection */}
        <div className={`mt-8 p-6 border border-[#f0ebe4]/8 transition-all duration-700 delay-300 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <p className="meta text-[9px] text-[#4a453f] mb-2">THE QUESTION NOBODY SAYS OUT LOUD</p>
          <p className="display-serif text-base font-semibold text-[#f0ebe4] mb-2">
            "What if I go through all of this and still don't pass?"
          </p>
          <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">
            If you complete SonoPrep and still don't feel ready, you don't keep guessing — you get your money back.
            That's our 14-day refund policy: no hoops, no questions about how much you used it.
            We're confident enough in the material to make buying feel safer than not buying.
          </p>
          <Link href="/products" className="inline-block mt-4 meta text-[10px] text-[#c85b3a] hover:underline">
            See all products and pricing →
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ── Credibility ───────────────────────────────────────────────────── */
function Credibility() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-24 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-5xl mx-auto">
        <div className={`grid md:grid-cols-2 gap-12 items-start transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>

          {/* Left — instructor */}
          <div>
            <span className="meta">THE INSTRUCTOR</span>
            <h2 className="display-serif text-3xl sm:text-4xl mt-3 font-semibold tracking-tight leading-snug">
              This content was taught in a real classroom before it was on a website.
            </h2>
            <p className="body-readable text-[#b8b0a4] mt-5 text-sm leading-relaxed">
              SonoPrep's curriculum comes directly from study materials developed at
              Houston International Cardiotech Ultrasound School in Houston, TX — where
              the RDMS instructor behind this content spent years watching students struggle
              with physics, then pass their credentials.
            </p>
            <p className="body-readable text-[#b8b0a4] mt-4 text-sm leading-relaxed">
              Every flashcard, exam question, and Physics Pearl was written by that instructor — not
              assembled by a content team, not AI-generated. The difference shows in how questions
              are framed: they test understanding, not memorization.
            </p>

            {/* Credibility anchor — specific, grounded, honest */}
            <div className="mt-6 p-4 border border-[#c85b3a]/15 bg-[#c85b3a]/[0.03]">
              <p className="meta text-[9px] text-[#4a453f] mb-2">BUILT TO THE ACTUAL EXAM</p>
              <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">
                Content is built from real SPI exam patterns and ARDMS domain weighting — 
                not generic sonography curriculum. Questions are designed around how the SPI is 
                actually written, not just what the field covers.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              {[
                { stat: "10+ yrs", label: "Clinical & teaching experience" },
                { stat: "RDMS",    label: "Active ARDMS credential holder" },
                { stat: "6",       label: "ARDMS SPI domains covered" },
                { stat: "Houston", label: "HICUS — verified school origin" },
              ].map(({ stat, label }) => (
                <div key={label} className="depth-border p-4">
                  <div className="display-serif text-xl font-bold text-[#c85b3a]">{stat}</div>
                  <div className="body-small text-[#6b6359] text-xs mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — honest early-stage proof */}
          <div>
            <span className="meta">HONEST ABOUT BEING NEW</span>
            <h3 className="display-serif text-xl font-semibold text-[#f0ebe4] mt-3 mb-5 leading-snug">
              We don't have 500 reviews yet. Here's what we do have.
            </h3>

            <div className="space-y-5">
              {[
                {
                  heading: "Curriculum with a documented track record",
                  body: "The methodology behind SonoPrep isn't new — it's the same curriculum used at a Houston ultrasound school where students went on to pass RDMS, RDCS, and RVT exams. We brought it online.",
                },
                {
                  heading: "Content written to ARDMS domain specifications",
                  body: "All 6 SPI domains are covered at the weightings ARDMS publishes. The exam simulator distributes questions accordingly — so you're not over-studying physics topics the exam barely tests.",
                },
                {
                  heading: "14-day refund if it doesn't work for you",
                  body: "We're confident enough in the material to offer a full refund within 14 days. No hoops. If it's not the right fit for how you study, you don't pay.",
                },
              ].map(({ heading, body }, i) => (
                <div key={heading} className="depth-border p-5 tactile-card" style={{ transitionDelay: visible ? `${i * 80}ms` : "0ms" }}>
                  <h4 className="display-serif text-sm font-semibold text-[#f0ebe4] mb-2">{heading}</h4>
                  <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">{body}</p>
                </div>
              ))}
            </div>

            <div className="mt-6">
              <Link href="/about" className="meta text-[10px] text-[#6b6359] hover:text-[#c85b3a] transition-colors">
                Read more about the instructor and the school →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Consequence Framing ───────────────────────────────────────────── */
function ConsequenceFraming() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-20 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-4xl mx-auto">

        <div className={`grid md:grid-cols-2 gap-10 items-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div>
            <span className="meta">THE REAL COST OF FAILING</span>
            <h2 className="display-serif text-3xl sm:text-4xl mt-3 font-semibold tracking-tight leading-snug">
              A failed SPI isn't just a failed exam.
            </h2>
            <p className="body-readable text-[#b8b0a4] mt-5 text-sm leading-relaxed">
              It delays every specialty exam behind it. It means paying ARDMS fees again.
              It means explaining the gap when you apply for positions.
              And it means more months studying material you may have already gotten wrong once.
            </p>
            <p className="body-readable text-[#b8b0a4] mt-4 text-sm leading-relaxed">
              Every week between you and passing the SPI is a week your certification is pushed back.
              The SPI isn't hard because the physics is hard — it's hard because most people
              study broadly instead of studying precisely what ARDMS tests.
              SonoPrep is built to fix that specific problem.
            </p>

            {/* Real urgency — no countdown, just context */}
            <div className="mt-6 p-4 border border-[#f0ebe4]/8">
              <p className="meta text-[9px] text-[#4a453f] mb-2">IF YOUR EXAM IS COMING UP</p>
              <p className="body-small text-[#b8b0a4] text-sm leading-relaxed">
                For students testing in the next 2–4 weeks: every day you wait is a day you could have 
                found a gap and fixed it. The demo takes 2 minutes and shows you where you stand right now.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {[
              { label: "Broad textbook studying", flag: false, desc: "Covers everything — including what the exam doesn't test" },
              { label: "Generic practice tests",  flag: false, desc: "No domain weighting, no clinical rationale, no gap analysis" },
              { label: "SonoPrep flashcards",     flag: true,  desc: "200+ cards mapped to the 6 ARDMS SPI domains" },
              { label: "SonoPrep simulator",      flag: true,  desc: "170 questions weighted to match real exam distribution" },
            ].map(({ label, flag, desc }) => (
              <div key={label} className={`flex items-start gap-4 p-4 border ${flag ? "border-[#c85b3a]/20 bg-[#c85b3a]/[0.03]" : "border-[#f0ebe4]/5 opacity-60"}`}>
                <span className={`mt-0.5 text-sm font-bold shrink-0 ${flag ? "text-[#c85b3a]" : "text-[#3a3530]"}`}>
                  {flag ? "✓" : "✗"}
                </span>
                <div>
                  <p className={`meta text-[10px] ${flag ? "text-[#f0ebe4]" : "text-[#4a453f]"}`}>{label}</p>
                  <p className="body-small text-xs text-[#6b6359] mt-0.5">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className={`mt-12 text-center transition-all duration-700 delay-300 ${visible ? "opacity-100" : "opacity-0"}`}>
          <Link href="/products" className="tactile-button px-8 py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all duration-300 inline-block meta text-[11px]">
            SEE THE PREP SYSTEM →
          </Link>
          <p className="meta text-[9px] text-[#3a3530] mt-3">14-day refund policy · 90-day access · instant unlock after checkout</p>
        </div>
      </div>
    </section>
  );
}

/* ── Clear Path — the system, not a purchase ──────────────────────── */
function ClearPath() {
  const { ref, visible } = useVisible();

  const steps = [
    { n: "01", label: "Start here", action: "Take the free demo", detail: "2 minutes, real interface, no account" },
    { n: "02", label: "See your gaps", action: "Check your domain results", detail: "Find out which of the 6 areas need work" },
    { n: "03", label: "Practice by domain", action: "Use flashcards + Physics Pearls", detail: "Target exactly what the exam weights" },
    { n: "04", label: "Walk in ready", action: "Take full 170-question exams", detail: "Simulate real conditions before test day" },
  ];

  return (
    <section ref={ref} className="py-20 px-6 border-t border-[#f0ebe4]/5 bg-[#c85b3a]/[0.02]">
      <div className="max-w-4xl mx-auto">
        <div className={`mb-12 text-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">HOW IT WORKS</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-3 font-semibold tracking-tight">
            A system, not just a purchase.
          </h2>
          <p className="body-readable text-[#6b6359] mt-3 text-sm max-w-xl mx-auto">
            Here's the path from where you are now to walking into the SPI with a plan.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map(({ n, label, action, detail }, i) => (
            <div
              key={n}
              className="depth-border p-5 relative"
              style={{ transitionDelay: visible ? `${i * 80}ms` : "0ms", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.6s, transform 0.6s" }}
            >
              <div className="display-serif text-4xl font-bold text-[#c85b3a]/20 mb-3">{n}</div>
              <div className="meta text-[9px] text-[#4a453f] mb-1">{label}</div>
              <p className="display-serif text-sm font-semibold text-[#f0ebe4] mb-2">{action}</p>
              <p className="body-small text-[#6b6359] text-xs">{detail}</p>
            </div>
          ))}
        </div>

        <div className={`mt-10 text-center transition-all duration-700 delay-400 ${visible ? "opacity-100" : "opacity-0"}`}>
          <Link href="/products" className="tactile-button px-8 py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all duration-300 inline-block meta text-[11px]">
            GET THE FULL SYSTEM — $99 →
          </Link>
          <p className="meta text-[9px] text-[#3a3530] mt-3">Or start smaller · Physics Pearls from $9</p>
        </div>
      </div>
    </section>
  );
}

/* ── Products section ──────────────────────────────────────────────── */
const PRODUCTS = [
  {
    key: "pearls",
    name: "Physics Pearls",
    price: "$9",
    tag: "BEST STARTING POINT",
    desc: "50 high-yield physics concepts in concise, memorable form. If you're early in your prep or short on time, start here.",
    features: ["50 concept summaries", "Clinical application examples", "ARDMS domain mapped"],
    bundle: false, featured: false, recommended: false,
  },
  {
    key: "flashcards",
    name: "SPI Flashcards",
    price: "$29",
    tag: "MASTER THE CONCEPTS",
    desc: "200+ cards with SM-2 spaced repetition. The algorithm surfaces what you're getting wrong and stops wasting time on what you already know.",
    features: ["200+ expert-written flashcards", "SM-2 spaced repetition", "Progress tracking per card"],
    bundle: false, featured: false, recommended: false,
  },
  {
    key: "simulator",
    name: "Exam Simulator",
    price: "$49",
    tag: "CLOSEST TO THE REAL EXAM",
    desc: "170 ARDMS domain-weighted questions with detailed clinical rationales. Per-domain analytics show exactly where you're losing points.",
    features: ["170 domain-weighted questions", "All 6 ARDMS SPI domains", "Detailed clinical rationales", "Per-domain performance analytics"],
    bundle: false, featured: true, recommended: false,
  },
  {
    key: "notes",
    name: "Study Notes",
    price: "$39",
    tag: "DEEP REFERENCE",
    desc: "159-page comprehensive guide covering all 6 SPI domains. Use this alongside the simulator for full coverage.",
    features: ["159 pages of content", "10 organized chapters", "Covers all 6 SPI domains"],
    bundle: false, featured: false, recommended: false,
  },
  {
    key: "bundle",
    name: "Premium Bundle",
    price: "$99",
    tag: "FULL SPI PREP SYSTEM — EVERYTHING YOU NEED TO PASS",
    desc: "All four products. The complete system. For less than the cost of a single retake fee, you get everything you need — no piecing resources together.",
    features: [
      "All 4 products included",
      "200+ flashcards + 50 Pearls",
      "170-question domain-weighted simulator",
      "159-page study notes",
      "One mistake on test day costs more than this bundle",
      "90-day full access",
    ],
    bundle: true, featured: true, recommended: true,
  },
];

function ProductsSection() {
  const { ref, visible } = useVisible();

  return (
    <section ref={ref} className="py-24 px-6 border-t border-[#f0ebe4]/5">
      <div className="max-w-6xl mx-auto">

        <div className={`mb-6 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <span className="meta">WHAT YOU GET</span>
          <h2 className="display-serif text-3xl sm:text-4xl mt-3 font-semibold tracking-tight max-w-lg">
            Pick a path. Or take the one we recommend.
          </h2>
          <p className="body-readable text-[#6b6359] mt-3 text-sm max-w-xl">
            Every product works standalone. If you have an exam in the next 60 days and want to cover everything, the bundle is the answer.
          </p>
        </div>

        {/* Bundle — dominant, first */}
        {PRODUCTS.filter(p => p.bundle).map((product) => (
          <div
            key={product.key}
            className="depth-border corner-arch p-7 mb-6 relative border-[#c85b3a]/25 bg-[#c85b3a]/[0.04]"
            style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.6s, transform 0.6s" }}
          >
            <div className="absolute top-0 left-0 bg-[#c85b3a] px-3 py-1 text-[9px] meta text-white">RECOMMENDED — BEST VALUE</div>
            <div className="pt-4 grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="meta text-[9px] text-[#c85b3a] mb-2">{product.tag}</div>
                <h3 className="display-serif text-2xl font-bold text-[#f0ebe4] mb-2">{product.name}</h3>
                <div className="flex items-baseline gap-3 mb-3">
                  <span className="text-3xl font-bold text-[#c85b3a]">{product.price}</span>
                  <span className="text-sm text-[#6b6359] line-through">$126</span>
                  <span className="meta text-[9px] text-[#4a453f]">/ 90-day access</span>
                </div>
                <p className="body-readable text-[#b8b0a4] text-sm leading-relaxed">{product.desc}</p>
              </div>
              <div>
                <ul className="space-y-2 mb-6">
                  {product.features.map((f) => (
                    <li key={f} className="flex items-center gap-3 text-sm text-[#b8b0a4]">
                      <span className="text-[#c85b3a] text-xs">✓</span>{f}
                    </li>
                  ))}
                </ul>
                <Link href="/products" className="tactile-button w-full block text-center py-3.5 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all meta text-[11px]">
                  GET THE BUNDLE — $99 →
                </Link>
                <p className="meta text-[9px] text-[#3a3530] text-center mt-2">14-day refund · instant access · no subscription</p>
              </div>
            </div>
          </div>
        ))}

        {/* Individual products */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {PRODUCTS.filter(p => !p.bundle).map((product, i) => (
            <div
              key={product.key}
              className={`depth-border corner-arch p-5 tactile-card relative flex flex-col ${product.featured ? "border-l-[3px] border-l-[#c85b3a]/60" : ""}`}
              style={{ transitionDelay: visible ? `${i * 60}ms` : "0ms", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.6s, transform 0.6s" }}
            >
              <div className="meta text-[9px] text-[#4a453f] mb-3">{product.tag}</div>
              <h3 className="display-serif text-base font-semibold text-[#f0ebe4] mb-1">{product.name}</h3>
              <div className="text-2xl font-semibold text-[#c85b3a] mb-2">{product.price}<span className="text-[9px] text-[#4a453f] ml-1">/ 90d</span></div>
              <p className="body-small text-[#6b6359] text-[11px] leading-relaxed flex-grow mb-5">{product.desc}</p>
              <Link href="/products" className="tactile-button py-2.5 text-center meta text-[10px] border border-[#c85b3a]/30 text-[#b8b0a4] hover:bg-[#c85b3a]/8 transition-all">
                GET STARTED →
              </Link>
            </div>
          ))}
        </div>

        {/* Trust strip */}
        <div className={`flex flex-wrap justify-center gap-6 pt-6 border-t border-[#f0ebe4]/5 transition-all duration-700 delay-400 ${visible ? "opacity-100" : "opacity-0"}`}>
          {[
            "90-day access on all products",
            "14-day full refund policy",
            "Instant access after checkout",
            "Written by an active RDMS instructor",
            "Covers all 6 ARDMS SPI domains",
          ].map((item) => (
            <span key={item} className="meta text-[9px] text-[#3a3530]">✓ {item}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Footer ────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="border-t border-[#f0ebe4]/5 py-12 mt-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between gap-8">
          <div>
            <div className="display-serif text-xl font-semibold text-[#f0ebe4] mb-2">SonoPrep</div>
            <div className="body-small text-[#4a453f] text-xs max-w-xs leading-relaxed">
              Built by sonographers, for sonographers.
              Covers RDMS, RDCS, RVT, and RMSKS SPI exam prep.
            </div>
          </div>
          <div className="flex gap-12">
            <div>
              <div className="meta text-[10px] mb-3 text-[#3a3530]">PRODUCT</div>
              <div className="space-y-2">
                <Link href="/demo"     className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Free Demo</Link>
                <Link href="/products" className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Pricing</Link>
              </div>
            </div>
            <div>
              <div className="meta text-[10px] mb-3 text-[#3a3530]">RESOURCES</div>
              <div className="space-y-2">
                <Link href="/blog"  className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Blog</Link>
                <Link href="/faq"   className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">FAQ</Link>
                <Link href="/about" className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">About</Link>
              </div>
            </div>
            <div>
              <div className="meta text-[10px] mb-3 text-[#3a3530]">LEGAL</div>
              <div className="space-y-2">
                <Link href="/privacy"       className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Privacy</Link>
                <Link href="/terms"         className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Terms</Link>
                <Link href="/accessibility" className="body-small text-[#4a453f] hover:text-[#f0ebe4] text-xs block transition-colors">Accessibility</Link>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t border-[#f0ebe4]/5 space-y-2 text-center">
          <p className="meta text-[9px] text-[#2e2b27]">
            © {new Date().getFullYear()} SonoPrep. All rights reserved. All educational content is original, proprietary, and protected by copyright.
            Unauthorized reproduction, redistribution, or resale of any content is strictly prohibited.
          </p>
          <p className="meta text-[9px] text-[#2e2b27]">
            SonoPrep is not affiliated with or endorsed by ARDMS. SPI® is a registered trademark of the American Registry for Diagnostic Medical Sonography.
            SonoPrep is an independent educational resource and does not represent ARDMS in any capacity.
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ── Page assembly ─────────────────────────────────────────────────── */
export function HomePageClient() {
  return (
    <div className="min-h-screen bg-[#0a0c10]">
      <Header />
      <main>
        <Hero />
        <DecisionMoment />
        <WhoIsThisFor />
        <MomentOfRealization />
        <DemoSection />
        <WhatThisIsNot />
        <ClearPath />
        <ConsequenceFraming />
        <Credibility />
        <ProductsSection />
      </main>
      <Footer />
    </div>
  );
}
