"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

type PriceIds = {
  flashcards: string | undefined;
  simulator:  string | undefined;
  pearls:     string | undefined;
  notes:      string | undefined;
  bundle:     string | undefined;
};

// Individual total: $29 + $9 + $49 + $39 = $126. Bundle = $99. Savings = $27.
// All numbers must be consistent. Never inflate the anchor price.
const PRODUCTS = [
  {
    key: "bundle",
    name: "Premium Bundle",
    price: "$99",
    strikethrough: "$126",
    savings: "One mistake on test day costs more than this bundle",
    tag: "FULL SPI PREP SYSTEM — EVERYTHING YOU NEED TO PASS",
    description: "All four products. The complete SPI prep system. Everything you need — no piecing resources together. For less than the cost of an ARDMS retake fee, you get the flashcard deck, the full domain-weighted simulator, Physics Pearls, and the 159-page study notes, all covering all 6 ARDMS SPI domains.",
    features: [
      "200+ expert-written flashcards",
      "SM-2 spaced repetition algorithm",
      "170-question domain-weighted exam simulator",
      "All 6 ARDMS SPI domains covered",
      "Detailed clinical rationales",
      "Per-domain performance analytics",
      "50 high-yield Physics Pearls",
      "159-page study notes (10 chapters)",
      "One mistake on test day costs more than this bundle",
    ],
    bundle: true,
    featured: true,
  },
  {
    key: "simulator",
    name: "Exam Simulator",
    price: "$49",
    tag: "CLOSEST TO THE REAL EXAM",
    description: "170 ARDMS domain-weighted questions with detailed clinical rationales. Per-domain analytics show exactly where you're losing points across all 6 SPI exam areas.",
    features: [
      "170 domain-weighted questions",
      "All 6 ARDMS SPI domains",
      "Detailed clinical rationales",
      "Per-domain performance analytics",
    ],
    bundle: false, featured: true,
  },
  {
    key: "flashcards",
    name: "SPI Flashcards",
    price: "$29",
    tag: "MASTER THE CONCEPTS",
    description: "200+ clinically focused flashcards with SM-2 spaced repetition. The algorithm prioritizes what you're getting wrong — so 30 minutes a day actually moves the needle.",
    features: [
      "200+ expert-written flashcards",
      "SM-2 spaced repetition",
      "Progress tracking per card",
      "Covers all 6 ARDMS SPI domains",
    ],
    bundle: false, featured: false,
  },
  {
    key: "pearls",
    name: "Physics Pearls",
    price: "$9",
    tag: "BEST LOW-RISK ENTRY POINT",
    description: "50 high-yield physics principles in concise, memorable summaries. Best starting point if you want to test the material before committing to the full system.",
    features: [
      "50 concept summaries",
      "Clinical application examples",
      "ARDMS domain mapped",
      "Quick reference format",
    ],
    bundle: false, featured: false,
  },
  {
    key: "notes",
    name: "Study Notes",
    price: "$39",
    tag: "COMPREHENSIVE REFERENCE",
    description: "159-page guide covering all 6 SPI domains across 10 organized chapters. Best used alongside the simulator for students who want deep coverage.",
    features: [
      "159 pages of content",
      "10 organized chapters",
      "Progress tracking",
      "Covers all 6 SPI domains",
    ],
    bundle: false, featured: false,
  },
];

export default function ProductsPage() {
  const [priceIds, setPriceIds] = useState<PriceIds | null>(null);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    fetch("/api/price-ids")
      .then(res => res.json())
      .then(data => setPriceIds(data))
      .finally(() => setLoading(false));
  }, []);

  const handleCheckout = async (productKey: keyof PriceIds) => {
    if (!priceIds || !priceIds[productKey]) {
      alert("Price not configured. Please contact support.");
      return;
    }
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        priceId:    priceIds[productKey],
        successUrl: window.location.origin + "/dashboard?success=true",
        cancelUrl:  window.location.origin + "/products?canceled=true",
      }),
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  };

  if (loading) return <div className="min-h-screen pt-32 px-6 text-[#3a3530] text-sm">Loading…</div>;

  const bundle     = PRODUCTS.find(p => p.bundle)!;
  const individual = PRODUCTS.filter(p => !p.bundle);

  return (
    <div className="min-h-screen pt-32 px-6 pb-24">
      <div className="max-w-5xl mx-auto">

        {/* Page header */}
        <div className="mb-14 border-b border-[#f0ebe4]/8 pb-10">
          <span className="meta">SPI EXAM PREP</span>
          <h1 className="display-display text-5xl sm:text-6xl mt-4 leading-[1.06]">
            Pass the SPI.<br /><span className="text-[#c85b3a]">Pick your path.</span>
          </h1>
          <p className="body-readable text-[#b8b0a4] max-w-xl mt-5">
            Every product covers the 6 ARDMS SPI domains. If you're not sure where to start,
            the bundle is the answer. If you want to try one thing first, Physics Pearls at $9
            is the lowest-risk entry point.
          </p>

          {/* What this is not — decision filter */}
          <div className="mt-7 p-5 border border-[#f0ebe4]/6 bg-[#f0ebe4]/[0.01]">
            <p className="meta text-[9px] text-[#4a453f] mb-3">BEFORE YOU BUY — SET THE RIGHT EXPECTATION</p>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { not: "Not a textbook", is: "Structured SPI prep based on ARDMS exam weighting" },
                { not: "Not random practice tests", is: "170 questions mapped to 6 specific domains at real exam ratios" },
                { not: "Not a subscription", is: "One payment. 90-day access. 14-day full refund policy." },
              ].map(({ not, is }) => (
                <div key={not}>
                  <p className="meta text-[9px] text-[#c85b3a] line-through mb-1">{not}</p>
                  <p className="body-small text-[#6b6359] text-xs">{is}</p>
                </div>
              ))}
            </div>
          </div>

          <p className="meta text-[9px] text-[#3a3530] mt-4">
            All products include 90-day access · 14-day full refund policy · Instant unlock after checkout
          </p>
        </div>

        {/* Bundle — primary recommendation */}
        <div className="depth-border corner-arch p-8 mb-10 relative border-[#c85b3a]/20 bg-[#c85b3a]/[0.03]">
          <div className="absolute top-0 left-0 bg-[#c85b3a] px-3 py-1 text-[9px] meta text-white">
            RECOMMENDED — BEST VALUE
          </div>
          <div className="pt-4 grid md:grid-cols-2 gap-10 items-start">
            <div>
              <div className="meta text-[9px] text-[#c85b3a] mb-2">{bundle.tag}</div>
              <h2 className="display-serif text-2xl font-bold text-[#f0ebe4] mb-3">{bundle.name}</h2>
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-4xl font-bold text-[#c85b3a]">{bundle.price}</span>
                <span className="text-sm text-[#4a453f] line-through">{bundle.strikethrough}</span>
                <span className="meta text-[9px] text-[#c85b3a]/70">{bundle.savings}</span>
                <span className="meta text-[9px] text-[#3a3530]">/ 90-day access</span>
              </div>
              <p className="body-readable text-[#b8b0a4] text-sm leading-relaxed">{bundle.description}</p>

              {/* Risk reversal */}
              <div className="mt-5 p-4 border border-[#f0ebe4]/6 bg-[#f0ebe4]/[0.01]">
                <p className="meta text-[9px] text-[#4a453f] mb-1">14-DAY REFUND POLICY</p>
                <p className="body-small text-[#6b6359] text-xs leading-relaxed">
                  If you go through this and still don't feel prepared, you get your money back. No questions about how much you used it.
                  We're confident enough in the material to make buying feel safer than not buying.
                </p>
              </div>
            </div>
            <div>
              <ul className="space-y-2.5 mb-7">
                {bundle.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm text-[#b8b0a4]">
                    <span className="text-[#c85b3a] text-xs shrink-0">✓</span>{f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleCheckout("bundle")}
                className="tactile-button w-full py-4 bg-[#c85b3a] text-white hover:bg-[#a8452a] transition-all meta text-[11px]"
              >
                GET THE BUNDLE — $99 →
              </button>
              <p className="meta text-[9px] text-[#3a3530] text-center mt-2">
                14-day full refund · instant access · no subscription
              </p>
            </div>
          </div>
        </div>

        {/* Individual products */}
        <div className="mb-4">
          <p className="meta text-[10px] text-[#3a3530] mb-5">OR START WITH ONE PRODUCT</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-12">
          {individual.map((product) => (
            <div
              key={product.key}
              className={`depth-border corner-arch p-6 tactile-card relative flex flex-col ${product.featured ? "border-l-[3px] border-l-[#c85b3a]/50" : ""}`}
            >
              {product.featured && (
                <div className="absolute top-0 left-0 bg-[#c85b3a]/70 px-2 py-0.5 text-[9px] meta text-white">MOST POPULAR</div>
              )}
              <div className="pt-5 flex-grow">
                <div className="meta text-[9px] text-[#4a453f] mb-2">{product.tag}</div>
                <h3 className="display-serif text-lg font-semibold text-[#f0ebe4] mb-1">{product.name}</h3>
                <div className="text-2xl font-semibold text-[#c85b3a] mb-3">
                  {product.price}<span className="text-[9px] text-[#4a453f] ml-1">/ 90-day access</span>
                </div>
                <p className="body-small text-[#b8b0a4] text-sm leading-relaxed mb-5">{product.description}</p>
                <ul className="space-y-1.5 mb-6">
                  {product.features.map((f) => (
                    <li key={f} className="flex items-center gap-2.5 text-xs text-[#6b6359]">
                      <span className="text-[#c85b3a] shrink-0">—</span>{f}
                    </li>
                  ))}
                </ul>
              </div>
              <button
                onClick={() => handleCheckout(product.key as keyof PriceIds)}
                className="tactile-button w-full py-3 text-center border border-[#c85b3a]/30 text-[#f0ebe4] hover:bg-[#c85b3a]/8 transition-all meta text-[10px]"
              >
                GET {product.name.toUpperCase()} →
              </button>
            </div>
          ))}
        </div>

        {/* Try before you buy */}
        <div className="border-t border-[#f0ebe4]/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="display-serif text-base font-semibold text-[#f0ebe4] mb-1">Not sure yet?</p>
            <p className="body-small text-[#6b6359] text-sm">Try the exam simulator and flashcards free — no account required.</p>
          </div>
          <Link href="/demo" className="tactile-button px-6 py-3 border border-[#f0ebe4]/15 text-[#b8b0a4] hover:text-[#f0ebe4] hover:border-[#f0ebe4]/25 transition-all meta text-[10px] shrink-0">
            TRY FREE DEMO →
          </Link>
        </div>

        {/* Legal */}
        <div className="mt-12 pt-6 border-t border-[#f0ebe4]/5 text-center">
          <p className="meta text-[9px] text-[#2e2b27]">
            © {new Date().getFullYear()} SonoPrep. All content is original and copyright protected. Unauthorized redistribution is prohibited.
            SonoPrep is not affiliated with or endorsed by ARDMS. SPI® is a registered trademark of ARDMS.
          </p>
        </div>
      </div>
    </div>
  );
}
