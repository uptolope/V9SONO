"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  BookOpen, Lightbulb, GraduationCap, FileText, Package,
  ArrowRight, Check, Zap, ShieldCheck, Users, Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

/* ─── Types ──────────────────────────────────────────────────────── */
export interface ProductData {
  key: string;
  name: string;
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  icon: LucideIcon;
  popular?: boolean;
  savingsLabel?: string;
}

/* ─── Product data ───────────────────────────────────────────────── */
// Individual prices: $29 + $9 + $49 + $39 = $126 actual total
// Bundle is $99 — honest $27 saving. Do NOT inflate the anchor price.
const INDIVIDUAL_TOTAL = 2900 + 900 + 4900 + 3900; // $126 in cents

export const PRODUCTS: ProductData[] = [
  {
    key: "SPI_FLASHCARDS",
    name: "SPI Flashcards",
    price: 2900,
    description:
      "200+ clinically focused flashcards with SM-2 spaced repetition. The algorithm prioritizes what you're getting wrong — so your study time actually moves the needle.",
    features: [
      "200+ expert-written flashcards",
      "SM-2 spaced repetition algorithm",
      "Progress tracking per card",
      "Covers all 6 ARDMS SPI domains",
    ],
    icon: BookOpen,
  },
  {
    key: "PHYSICS_PEARLS",
    name: "Physics Pearls",
    price: 900,
    description:
      "50 high-yield physics principles — concise, memorable, and mapped to what ARDMS actually tests. Best starting point if you're not ready to commit to the full system.",
    features: [
      "50 high-yield concept summaries",
      "Clinical application examples",
      "ARDMS domain mapping",
      "Quick reference format",
    ],
    icon: Lightbulb,
  },
  {
    key: "EXAM_SIMULATOR",
    name: "Exam Simulator",
    price: 4900,
    description:
      "170 ARDMS domain-weighted practice questions with detailed clinical rationales and per-domain analytics. This is the closest thing to the real SPI short of sitting it.",
    features: [
      "170 domain-weighted questions",
      "All 6 ARDMS SPI domains covered",
      "Detailed clinical rationales",
      "Per-domain performance analytics",
    ],
    icon: GraduationCap,
    popular: true,
  },
  {
    key: "STUDY_NOTES",
    name: "Study Notes",
    price: 3900,
    description:
      "159-page comprehensive guide covering all 6 SPI domains across 10 organized chapters. Use alongside the simulator for full coverage.",
    features: [
      "159 pages of content",
      "10 organized chapters",
      "Reading progress tracking",
      "Covers all 6 SPI domains",
    ],
    icon: FileText,
  },
  {
    key: "PREMIUM_BUNDLE",
    name: "Premium Bundle",
    price: 9900,
    originalPrice: INDIVIDUAL_TOTAL, // $126 — the honest individual total
    description:
      "All four products. Everything you need — no piecing resources together. For less than the cost of a single retake fee, you get the complete system: flashcards, simulator, Physics Pearls, and study notes.",
    features: [
      "All 4 products included",
      "200+ flashcards + 50 Pearls",
      "170-question domain-weighted simulator",
      "159-page study notes",
      "One mistake on test day costs more than this bundle",
      "90-day full access",
    ],
    icon: Package,
    savingsLabel: "Full SPI Prep System",
  },
];

/* ─── Trust bar ──────────────────────────────────────────────────── */
function TrustBar() {
  return (
    <div className="flex flex-wrap justify-center gap-6 text-xs text-cream-dim/50">
      {[
        { icon: ShieldCheck, text: "14-day refund policy" },
        { icon: Zap,         text: "Instant access after checkout" },
        { icon: Users,       text: "Written by an RDMS instructor" },
        { icon: Clock,       text: "90-day access" },
      ].map(({ icon: Icon, text }) => (
        <div key={text} className="flex items-center gap-1.5">
          <Icon className="h-3.5 w-3.5 text-teal/50" />
          {text}
        </div>
      ))}
    </div>
  );
}

/* ─── Bundle value strip ─────────────────────────────────────────── */
function BundleValueStrip() {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-teal/20 bg-teal/[0.04] px-4 py-2.5">
      <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-teal/70" />
      <span className="text-xs text-cream-dim/70">
        90-day access to all 4 products · 14-day full refund policy · no subscription
      </span>
    </div>
  );
}

/* ─── Product Card ───────────────────────────────────────────────── */
interface ProductCardProps {
  product: ProductData;
  onPurchase?: (key: string) => void;
}

function ProductCard({ product, onPurchase }: ProductCardProps) {
  const isBundle = product.key === "PREMIUM_BUNDLE";

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.01 }}
      transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      className="group relative"
    >
      {/* Premium glow effect on hover */}
      <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-teal/0 via-teal/20 to-teal/0 opacity-0 group-hover:opacity-100 blur-xl transition-all duration-500" />

      <Card
        className={`relative overflow-hidden transition-all duration-500 ease-smooth relative z-10 ${
          isBundle
            ? "border-teal/40 shadow-glow col-span-1 sm:col-span-2 bg-gradient-to-br from-charcoal via-slate/80 to-charcoal"
            : "hover:border-teal/30 hover:shadow-glow bg-gradient-to-br from-charcoal/90 via-slate/60 to-charcoal/90"
        }`}
      >
        {/* Hover glow */}
        <div className="pointer-events-none absolute inset-0 rounded opacity-0 transition-opacity duration-500 group-hover:opacity-100 bg-gradient-to-br from-teal/[0.04] to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-teal/0 to-transparent transition-all duration-500 group-hover:via-teal/50" />

        {/* Animated corner decoration */}
        <motion.div
          className="absolute -right-12 -top-12 h-24 w-24 rounded-full bg-teal/[0.03] blur-2xl group-hover:bg-teal/[0.08] transition-all duration-500"
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />

        <CardHeader className="relative">
          <div className="flex items-center justify-between">
            <motion.div
              className="flex h-12 w-12 items-center justify-center rounded-xl bg-mist transition-all duration-300 group-hover:bg-teal/10 group-hover:shadow-glow group-hover:scale-110"
              whileHover={{ rotate: [0, -10, 10, 0] }}
              transition={{ duration: 0.5 }}
            >
              <product.icon className="h-6 w-6 text-teal transition-colors duration-300 group-hover:text-teal-glow" />
            </motion.div>
            <div className="flex gap-2 flex-wrap justify-end">
              {product.popular && (
                <Badge className="relative overflow-hidden animate-border-glow">
                  <motion.span
                    className="absolute inset-0 bg-teal/20"
                    animate={{ opacity: [0, 0.4, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <span className="relative">Most Popular</span>
                </Badge>
              )}
              {product.savingsLabel && (
                <Badge variant="amber" className="shimmer-badge relative overflow-hidden">
                  <motion.span
                    className="absolute inset-0 bg-amber/20"
                    animate={{ x: ["-100%", "100%"] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  />
                  <span className="relative">{product.savingsLabel}</span>
                </Badge>
              )}
            </div>
          </div>
          <CardTitle className="mt-5 text-2xl font-bold text-cream group-hover:text-teal-glow transition-colors duration-300">{product.name}</CardTitle>
        </CardHeader>

        <CardContent className="relative space-y-5">
          <p className="text-base text-cream-dim leading-relaxed">{product.description}</p>

          {/* Price block */}
          <div className="relative">
            <div className="absolute -inset-px rounded-lg bg-gradient-to-r from-teal/10 via-transparent to-teal/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="space-y-1 relative p-4 rounded-lg bg-obsidian/30">
              <div className="flex items-baseline gap-3">
                <motion.span
                  className="font-mono text-4xl font-bold text-cream group-hover:text-teal-glow transition-colors duration-300"
                  whileHover={{ scale: 1.05 }}
                >
                  {formatCurrency(product.price)}
                </motion.span>
                {/* Anchor price — always the honest individual total, never inflated */}
                {isBundle && product.originalPrice && (
                  <motion.span
                    className="font-mono text-lg text-cream-dim/40 line-through decoration-red-400/50"
                    animate={{ opacity: [0.4, 0.6, 0.4] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    {formatCurrency(product.originalPrice)}
                  </motion.span>
                )}
                <span className="font-mono text-xs text-cream-dim/50">/ 90-day access</span>
              </div>
              {isBundle && product.originalPrice && (
                <p className="font-mono text-sm text-teal/70 flex items-center gap-2">
                  <motion.span
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    ↓
                  </motion.span>
                  Save {formatCurrency(product.originalPrice - product.price)} vs buying individually
                </p>
              )}
            </div>
          </div>

          {/* Bundle value strip */}
          {isBundle && <BundleValueStrip />}

          {/* Features */}
          <ul className="space-y-3">
            {product.features.map((f, index) => (
              <motion.li
                key={f}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3 text-sm text-cream-dim group-hover:text-cream-dim/80 transition-colors"
              >
                <motion.div
                  className="flex h-5 w-5 items-center justify-center rounded-full bg-teal/10 group-hover:bg-teal/20 transition-colors"
                  whileHover={{ scale: 1.2, rotate: 180 }}
                >
                  <Check className="h-3 w-3 text-teal" />
                </motion.div>
                {f}
              </motion.li>
            ))}
          </ul>

          {/* CTA */}
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              className={`w-full group/btn transition-all duration-300 ${
                isBundle ? "bg-gradient-to-r from-amber to-amber-dim hover:from-amber-dim hover:to-amber text-obsidian font-bold" : ""
              }`}
              size="lg"
              variant={isBundle ? "default" : "default"}
              onClick={() => onPurchase?.(product.key)}
            >
              <span className="relative">
                {isBundle ? "Get the Full Bundle — $99" : `Get ${product.name}`}
              </span>
              <motion.div
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <ArrowRight className="ml-1 h-4 w-4 transition-transform duration-300 group-hover/btn:translate-x-2" />
              </motion.div>
            </Button>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ─── Product Grid ───────────────────────────────────────────────── */
interface ProductGridProps {
  onPurchase?: (productKey: string) => void;
}

export function ProductGrid({ onPurchase }: ProductGridProps) {
  return (
    <section className="py-24" id="products">
      <div className="mx-auto max-w-7xl px-6">

        {/* Section heading */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <p className="font-mono text-xs uppercase tracking-widest text-teal">Study Materials</p>
          <h2 className="mt-3 font-display text-3xl font-bold text-cream sm:text-4xl">
            Everything You Need to Pass the SPI
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-cream-dim">
            170 domain-weighted questions, 200+ spaced repetition flashcards, 50 Physics Pearls,
            and 159 pages of study notes — all written by a credentialed RDMS instructor.
            Start with a free demo. Upgrade when you're ready.
          </p>
        </motion.div>

        {/* Introductory pricing banner */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mt-10 mx-auto max-w-2xl flex items-center justify-center gap-3 rounded-xl border border-teal/15 bg-teal/[0.04] px-5 py-3"
        >
          <Zap className="h-4 w-4 text-teal shrink-0" />
          <p className="text-sm text-cream-dim">
            <span className="text-cream font-semibold">Introductory pricing</span> —
            SonoPrep is a new platform. These are launch rates.
            All products include a 14-day full refund policy.
          </p>
        </motion.div>

        {/* Card grid */}
        <div className="mt-12 grid gap-8 sm:grid-cols-2">
          {PRODUCTS.map((product, i) => (
            <motion.div
              key={product.key}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.1, ease: [0.4, 0, 0.2, 1] }}
              className={product.key === "PREMIUM_BUNDLE" ? "sm:col-span-2" : ""}
            >
              <ProductCard product={product} onPurchase={onPurchase} />
            </motion.div>
          ))}
        </div>

        {/* Trust bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-10"
        >
          <TrustBar />
        </motion.div>

        {/* Copyright notice */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-8 text-center"
        >
          <p className="text-xs text-cream-dim/30">
            All content is original, proprietary, and copyright protected.
            SonoPrep is not affiliated with ARDMS. SPI® is a registered trademark of the American Registry for Diagnostic Medical Sonography.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
