"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Play,
  Activity,
  Brain,
  Target,
  TrendingUp,
  Clock,
  Shield,
  Award,
  Zap,
  BookOpen,
  FileText,
  GraduationCap,
  Crown,
  Menu,
  X,
  Check,
} from "lucide-react";

// ─── Hooks ────────────────────────────────────────────────────────────────────

function useInView(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) { setInView(true); obs.disconnect(); }
      },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function useSpringCounter(target: number, active: boolean, delay = 0) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!active) return;
    const timer = setTimeout(() => {
      const dur = 1800;
      const t0 = performance.now();
      let raf: number;
      const tick = (now: number) => {
        const p = Math.min((now - t0) / dur, 1);
        const ease = 1 - Math.pow(1 - p, 3);
        const overshoot = p > 0.82 && p < 1
          ? Math.sin(((p - 0.82) / 0.18) * Math.PI) * 0.028
          : 0;
        setVal(Math.round(target * Math.min(ease + overshoot, 1.03)));
        if (p < 1) raf = requestAnimationFrame(tick);
        else setVal(target);
      };
      raf = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(raf);
    }, delay);
    return () => clearTimeout(timer);
  }, [target, active, delay]);
  return val;
}

function useLiveClock() {
  const [time, setTime] = useState("--:--:--");
  useEffect(() => {
    const tick = () =>
      setTime(new Date().toLocaleTimeString("en-US", { hour12: false }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return time;
}

// ─── Precision Canvas (B-mode Ultrasound Simulator) ──────────────────────────

function PrecisionCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0.5, y: 0.5 });
  const animRef = useRef<number>(0);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;

    let W = 0, H = 0;
    let scanX = 80;
    const SCAN_SPEED = 1.6;

    // Pre-built tissue map (small, tiled)
    let tissueMap: HTMLCanvasElement | null = null;

    function buildTissueMap() {
      const TW = 320, TH = 320;
      const tc = document.createElement("canvas");
      tc.width = TW; tc.height = TH;
      const tx = tc.getContext("2d")!;
      const img = tx.createImageData(TW, TH);
      for (let y = 0; y < TH; y++) {
        for (let x = 0; x < TW; x++) {
          const i = (y * TW + x) * 4;
          const depth = y / TH;
          const tgc = depth < 0.06 ? depth / 0.06 : depth > 0.9 ? (1 - depth) / 0.1 : 1;
          const layA = Math.abs(Math.sin(y * 0.055 + x * 0.009)) * 0.45;
          const layB = Math.abs(Math.sin(y * 0.19 + 0.6)) * 0.35;
          const layC = Math.abs(Math.sin(x * 0.04 + y * 0.025)) * 0.2;
          const noise = Math.random();
          const speck = noise > 0.92 ? (noise - 0.92) * 12 : 0;
          const v = Math.min(255, Math.round((layA + layB + layC + speck) * tgc * 52));
          img.data[i] = v + 1;
          img.data[i + 1] = v;
          img.data[i + 2] = v + 6;
          img.data[i + 3] = 255;
        }
      }
      tx.putImageData(img, 0, 0);
      tissueMap = tc;
    }

    function resize() {
      const dpr = Math.min(window.devicePixelRatio, 2);
      const rect = canvas!.getBoundingClientRect();
      W = rect.width; H = rect.height;
      canvas!.width = W * dpr;
      canvas!.height = H * dpr;
      ctx.scale(dpr, dpr);
      buildTissueMap();
    }

    function draw() {
      timeRef.current++;
      const t = timeRef.current;
      ctx.clearRect(0, 0, W, H);

      // ── Base void ──────────────────────────────────────────────
      ctx.fillStyle = "#06080E";
      ctx.fillRect(0, 0, W, H);

      // Subtle warm radial (amber ambient)
      const amb = ctx.createRadialGradient(W * 0.5, H * 0.38, 0, W * 0.5, H * 0.5, W * 0.65);
      amb.addColorStop(0, "rgba(200,146,58,0.025)");
      amb.addColorStop(1, "rgba(6,8,14,0)");
      ctx.fillStyle = amb;
      ctx.fillRect(0, 0, W, H);

      // ── Precision grid ──────────────────────────────────────────
      const LEFT = 54, RIGHT = W - 28;
      const gridW = RIGHT - LEFT;
      const COLS = 12, ROWS = 8;
      ctx.strokeStyle = "rgba(200,146,58,0.045)";
      ctx.lineWidth = 1;
      for (let r = 0; r <= ROWS; r++) {
        const y = (H / ROWS) * r;
        ctx.beginPath(); ctx.moveTo(LEFT, y); ctx.lineTo(RIGHT, y); ctx.stroke();
      }
      for (let c = 0; c <= COLS; c++) {
        const x = LEFT + (gridW / COLS) * c;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }

      // ── Tissue image left of scan ───────────────────────────────
      if (tissueMap && scanX > LEFT) {
        ctx.globalAlpha = 0.72;
        // Tile tissue map across the scanned region
        const pw = tissueMap.width;
        const ph = tissueMap.height;
        for (let ty = 0; ty < H; ty += ph) {
          for (let tx2 = LEFT; tx2 < scanX; tx2 += pw) {
            const drawW = Math.min(pw, scanX - tx2);
            ctx.drawImage(tissueMap, 0, 0, drawW, ph, tx2, ty, drawW, Math.min(ph, H - ty));
          }
        }
        ctx.globalAlpha = 1;

        // Gain taper (darker at edges)
        const gainL = ctx.createLinearGradient(LEFT, 0, LEFT + 40, 0);
        gainL.addColorStop(0, "rgba(6,8,14,0.7)");
        gainL.addColorStop(1, "rgba(6,8,14,0)");
        ctx.fillStyle = gainL;
        ctx.fillRect(LEFT, 0, 40, H);
      }

      // ── Active scanline ─────────────────────────────────────────
      const sg = ctx.createLinearGradient(scanX - 4, 0, scanX + 4, 0);
      sg.addColorStop(0, "rgba(200,146,58,0)");
      sg.addColorStop(0.5, "rgba(232,170,85,0.88)");
      sg.addColorStop(1, "rgba(200,146,58,0)");
      ctx.fillStyle = sg;
      ctx.fillRect(scanX - 4, 0, 8, H);

      // Trail glow
      const trail = ctx.createLinearGradient(scanX - 60, 0, scanX, 0);
      trail.addColorStop(0, "rgba(200,146,58,0)");
      trail.addColorStop(1, "rgba(200,146,58,0.06)");
      ctx.fillStyle = trail;
      ctx.fillRect(scanX - 60, 0, 60, H);

      // Ahead: dark curtain (not-yet-scanned region)
      if (scanX < RIGHT) {
        const curtain = ctx.createLinearGradient(scanX, 0, scanX + 6, 0);
        curtain.addColorStop(0, "rgba(6,8,14,0.9)");
        curtain.addColorStop(1, "rgba(6,8,14,0)");
        ctx.fillStyle = curtain;
        ctx.fillRect(scanX, 0, Math.min(6, RIGHT - scanX), H);
        ctx.fillStyle = "rgba(6,8,14,0.55)";
        ctx.fillRect(scanX + 6, 0, RIGHT - scanX - 6, H);
      }

      // ── Depth scale (left ruler) ────────────────────────────────
      ctx.globalAlpha = 0.22;
      ctx.strokeStyle = "#C8923A";
      ctx.fillStyle = "#C8923A";
      ctx.lineWidth = 1;
      ctx.font = "8.5px 'Space Mono', monospace";
      for (let r = 0; r <= ROWS; r++) {
        const y = (H / ROWS) * r;
        const tickLen = r % 2 === 0 ? 14 : 7;
        ctx.beginPath(); ctx.moveTo(LEFT - tickLen, y); ctx.lineTo(LEFT, y); ctx.stroke();
        if (r % 2 === 0 && r > 0) {
          ctx.globalAlpha = 0.14;
          ctx.fillText(`${r * 2}`, 4, y + 3.5);
          ctx.globalAlpha = 0.22;
        }
      }
      ctx.globalAlpha = 0.1;
      ctx.fillText("cm", 4, H - 7);

      // ── Focal zone (right axis) ─────────────────────────────────
      const fzY = H * 0.36 + Math.sin(t * 0.004) * H * 0.008;
      const fzH = H * 0.24;
      ctx.globalAlpha = 0.28;
      ctx.strokeStyle = "#E8AA55";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(RIGHT + 6, fzY);
      ctx.lineTo(RIGHT + 18, fzY + 8);
      ctx.lineTo(RIGHT + 6, fzY + 16);
      ctx.stroke();
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(RIGHT + 20, fzY); ctx.lineTo(RIGHT + 20, fzY + fzH); ctx.stroke();
      ctx.globalAlpha = 1;

      // ── System readout (top-right) ──────────────────────────────
      ctx.globalAlpha = 0.13;
      ctx.fillStyle = "#EDE8E0";
      ctx.font = "9.5px 'Space Mono', monospace";
      ctx.textAlign = "right";
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, "0");
      const mm = String(now.getMinutes()).padStart(2, "0");
      const ss = String(now.getSeconds()).padStart(2, "0");
      ctx.fillText(`${hh}:${mm}:${ss}`, RIGHT - 4, 22);
      ctx.fillText("Fr: 18Hz", RIGHT - 4, 36);
      ctx.fillText("Depth: 16cm", RIGHT - 4, 50);
      ctx.fillText("Gain: 54dB", RIGHT - 4, 64);
      ctx.fillText("THI On", RIGHT - 4, 78);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;

      // ── Patient label (top-left) ────────────────────────────────
      ctx.globalAlpha = 0.1;
      ctx.fillStyle = "#EDE8E0";
      ctx.font = "9px 'Space Mono', monospace";
      ctx.fillText("SONOPREP / SPI PREP", LEFT + 4, 22);
      ctx.fillText("Linear Probe · 12MHz", LEFT + 4, 36);
      ctx.globalAlpha = 1;

      // ── Mouse crosshair ─────────────────────────────────────────
      const mx = mouseRef.current.x * W;
      const my = mouseRef.current.y * H;
      ctx.globalAlpha = 0.14;
      ctx.strokeStyle = "#E8AA55";
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 10]);
      ctx.beginPath(); ctx.moveTo(mx, 0); ctx.lineTo(mx, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, my); ctx.lineTo(W, my); ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      ctx.moveTo(mx, my - 5.5); ctx.lineTo(mx + 5.5, my);
      ctx.lineTo(mx, my + 5.5); ctx.lineTo(mx - 5.5, my);
      ctx.closePath();
      ctx.stroke();

      // Distance readout at crosshair
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = "#C8923A";
      ctx.font = "8px 'Space Mono', monospace";
      const depthCm = ((my / H) * 16).toFixed(1);
      ctx.fillText(`${depthCm}cm`, mx + 8, my - 4);
      ctx.globalAlpha = 1;

      // ── Vignette ────────────────────────────────────────────────
      const vig = ctx.createRadialGradient(W / 2, H / 2, H * 0.18, W / 2, H / 2, H * 0.9);
      vig.addColorStop(0, "rgba(0,0,0,0)");
      vig.addColorStop(1, "rgba(0,0,0,0.72)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, W, H);

      // Advance scan line
      if (scanX >= RIGHT) scanX = LEFT;
      scanX += SCAN_SPEED;

      animRef.current = requestAnimationFrame(draw);
    }

    resize();
    draw();

    const onResize = () => { scanX = 80; resize(); };
    const onMouse = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: (e.clientX - r.left) / r.width,
        y: (e.clientY - r.top) / r.height,
      };
    };

    window.addEventListener("resize", onResize);
    canvas.addEventListener("mousemove", onMouse);

    return () => {
      window.removeEventListener("resize", onResize);
      canvas.removeEventListener("mousemove", onMouse);
      cancelAnimationFrame(animRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ touchAction: "none" }}
    />
  );
}

// ─── Navigation ───────────────────────────────────────────────────────────────

const NAV_LINKS = [
  { name: "Products", href: "#products" },
  { name: "Features", href: "#features" },
  { name: "Demo", href: "/demo" },
  { name: "Dashboard", href: "/dashboard" },
];

function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const clock = useLiveClock();

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 48);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const handleAnchor = (href: string) => {
    setMobileOpen(false);
    if (href.startsWith("#")) {
      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
          scrolled
            ? "bg-[#06080E]/93 backdrop-blur-2xl border-b border-[#EDE8E0]/[0.055] py-3"
            : "bg-transparent py-6"
        }`}
      >
        <div className="max-w-7xl mx-auto px-8 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative w-8 h-8 flex items-center justify-center">
              <div
                className="absolute inset-0 border border-[#C8923A]/35 rotate-45 transition-transform duration-500 group-hover:rotate-[55deg]"
                style={{ borderRadius: "2px" }}
              />
              <Activity className="w-3.5 h-3.5 text-[#C8923A] relative z-10" />
            </div>
            <span className="font-display text-[1.15rem] tracking-tight text-[#EDE8E0]">
              Sono<span className="text-[#C8923A]">Prep</span>
            </span>
          </Link>

          {/* Center links */}
          <div className="hidden lg:flex items-center gap-10">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={
                  link.href.startsWith("#")
                    ? (e) => { e.preventDefault(); handleAnchor(link.href); }
                    : undefined
                }
                className="font-mono text-[0.72rem] uppercase tracking-[0.14em] text-[#857F79] hover:text-[#EDE8E0] transition-colors duration-300 relative group"
              >
                {link.name}
                <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-[#C8923A] group-hover:w-full transition-all duration-400 ease-out" />
              </Link>
            ))}
          </div>

          {/* Right: clock + CTAs */}
          <div className="hidden lg:flex items-center gap-6">
            <span className="font-mono text-[0.67rem] tracking-wider text-[#3A3835] tabular-nums select-none">
              {clock}
            </span>
            <Link
              href="/demo"
              className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#857F79] hover:text-[#EDE8E0] transition-colors duration-300"
            >
              Try Free
            </Link>
            <Link
              href="/auth/signin"
              className="relative px-5 py-2.5 bg-[#C8923A] text-[#06080E] font-mono text-[0.72rem] uppercase tracking-[0.12em] font-bold overflow-hidden group"
            >
              <span className="relative z-10 transition-colors duration-300 group-hover:text-[#06080E]">
                Get Started
              </span>
              <span className="absolute inset-0 bg-[#E8AA55] translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            </Link>
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-1.5 text-[#EDE8E0]"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden bg-[#06080E]/98 backdrop-blur-2xl flex flex-col pt-24 px-8">
          {NAV_LINKS.map((link, i) => (
            <Link
              key={link.name}
              href={link.href}
              onClick={() =>
                link.href.startsWith("#")
                  ? handleAnchor(link.href)
                  : setMobileOpen(false)
              }
              className="py-5 border-b border-[#EDE8E0]/[0.07] font-display text-[2rem] text-[#EDE8E0] hover:text-[#C8923A] transition-colors duration-300"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              {link.name}
            </Link>
          ))}
          <div className="mt-10 flex flex-col gap-4">
            <Link
              href="/demo"
              onClick={() => setMobileOpen(false)}
              className="py-3.5 border border-[#EDE8E0]/15 text-center font-mono text-[0.75rem] uppercase tracking-[0.14em] text-[#EDE8E0]"
            >
              Try Free Demo
            </Link>
            <Link
              href="/auth/signin"
              onClick={() => setMobileOpen(false)}
              className="py-3.5 bg-[#C8923A] text-center font-mono text-[0.75rem] uppercase tracking-[0.14em] text-[#06080E] font-bold"
            >
              Get Started
            </Link>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────

function HeroStats({ active }: { active: boolean }) {
  const STATS = [
    { target: 2400, suffix: "+", label: "Flashcards", delay: 200 },
    { target: 98, suffix: "%", label: "Pass Rate", delay: 420 },
    { target: 150, suffix: "+", label: "Physics Pearls", delay: 620 },
  ];
  const v0 = useSpringCounter(STATS[0].target, active, STATS[0].delay);
  const v1 = useSpringCounter(STATS[1].target, active, STATS[1].delay);
  const v2 = useSpringCounter(STATS[2].target, active, STATS[2].delay);
  const vals = [v0, v1, v2];

  return (
    <div className="grid grid-cols-3 max-w-[480px] mx-auto overflow-hidden border border-[#EDE8E0]/[0.08]">
      {STATS.map((s, i) => (
        <div
          key={s.label}
          className={`px-6 py-5 text-center bg-[#0A0D16]/65 backdrop-blur ${
            i < 2 ? "border-r border-[#EDE8E0]/[0.08]" : ""
          }`}
        >
          <div className="font-display text-[2.2rem] sm:text-[2.6rem] text-[#EDE8E0] tabular-nums leading-none">
            {vals[i].toLocaleString()}{s.suffix}
          </div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.22em] text-[#3A3835] mt-2">
            {s.label}
          </div>
        </div>
      ))}
    </div>
  );
}

function Hero() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [160, 550, 920, 1380].map((d, i) =>
      setTimeout(() => setPhase(i + 1), d)
    );
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <PrecisionCanvas />

      {/* Edge gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#06080E]/55 via-transparent to-[#06080E] pointer-events-none z-10" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#06080E]/65 via-transparent to-[#06080E]/65 pointer-events-none z-10" />

      {/* Precision corner brackets */}
      {[
        { pos: "top-8 left-8", r: "0" },
        { pos: "top-8 right-8", r: "90" },
        { pos: "bottom-8 right-8", r: "180" },
        { pos: "bottom-8 left-8", r: "270" },
      ].map(({ pos, r }, i) => (
        <div
          key={i}
          className={`absolute ${pos} z-20 pointer-events-none`}
          style={{ opacity: 0.18, transform: `rotate(${r}deg)` }}
        >
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <path d="M0 9V0H9" stroke="#C8923A" strokeWidth="1.5" />
          </svg>
        </div>
      ))}

      {/* Vertical rule lines */}
      <div className="absolute top-0 left-[22%] w-px h-full bg-gradient-to-b from-transparent via-[#EDE8E0]/[0.03] to-transparent pointer-events-none z-10" />
      <div className="absolute top-0 right-[22%] w-px h-full bg-gradient-to-b from-transparent via-[#EDE8E0]/[0.03] to-transparent pointer-events-none z-10" />

      {/* Side label — left */}
      <div className="absolute left-8 top-1/2 -translate-y-1/2 z-20 hidden xl:flex items-center gap-3 pointer-events-none">
        <div className="w-px h-20 bg-gradient-to-b from-transparent via-[#C8923A]/25 to-transparent" />
        <span
          className="font-mono text-[0.6rem] uppercase tracking-[0.28em] text-[#3A3835]"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          SPI Examination Preparation
        </span>
      </div>

      {/* Side label — right */}
      <div className="absolute right-8 top-1/2 -translate-y-1/2 z-20 hidden xl:flex items-center gap-3 pointer-events-none">
        <span
          className="font-mono text-[0.6rem] uppercase tracking-[0.28em] text-[#3A3835]"
          style={{ writingMode: "vertical-rl" }}
        >
          ARDMS · Sonography Principles
        </span>
        <div className="w-px h-20 bg-gradient-to-b from-transparent via-[#C8923A]/25 to-transparent" />
      </div>

      {/* Main content */}
      <div className="relative z-20 max-w-5xl mx-auto px-8 text-center pt-32 pb-20">

        {/* Eyebrow */}
        <div
          className="mb-10 transition-all duration-700"
          style={{ opacity: phase >= 1 ? 1 : 0, transform: phase >= 1 ? "translateY(0)" : "translateY(16px)" }}
        >
          <div className="inline-flex items-center gap-4">
            <div className="w-10 h-px bg-gradient-to-r from-transparent to-[#C8923A]/60" />
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.26em] text-[#C8923A]">
              Premium Exam Preparation
            </span>
            <div className="w-10 h-px bg-gradient-to-l from-transparent to-[#C8923A]/60" />
          </div>
        </div>

        {/* Headline — Cormorant editorial stacking */}
        <h1 className="mb-10 tracking-tight">
          <span
            className="block font-display font-semibold text-[#EDE8E0] leading-[0.92]
              text-[3.8rem] sm:text-[5.2rem] md:text-[6.8rem] lg:text-[7.8rem]
              transition-all duration-900"
            style={{ opacity: phase >= 2 ? 1 : 0, transform: phase >= 2 ? "translateY(0)" : "translateY(24px)", transitionDelay: "60ms" }}
          >
            Master the
          </span>
          <span
            className="block font-display font-semibold italic text-[#C8923A] leading-[0.92]
              text-[3.8rem] sm:text-[5.2rem] md:text-[6.8rem] lg:text-[7.8rem]
              transition-all duration-900"
            style={{ opacity: phase >= 2 ? 1 : 0, transform: phase >= 2 ? "translateY(0)" : "translateY(24px)", transitionDelay: "120ms" }}
          >
            SPI Exam
          </span>
          <span
            className="block font-display font-light text-[#4A4542] leading-[1.05]
              text-[2.4rem] sm:text-[3.2rem] md:text-[4.2rem] lg:text-[4.8rem]
              mt-2 transition-all duration-900"
            style={{ opacity: phase >= 2 ? 1 : 0, transform: phase >= 2 ? "translateY(0)" : "translateY(24px)", transitionDelay: "200ms" }}
          >
            with Clinical Precision
          </span>
        </h1>

        {/* Sub */}
        <p
          className="text-[1rem] sm:text-[1.08rem] text-[#857F79] max-w-[520px] mx-auto leading-relaxed mb-12 transition-all duration-700"
          style={{ opacity: phase >= 3 ? 1 : 0, transform: phase >= 3 ? "translateY(0)" : "translateY(14px)", transitionDelay: "80ms" }}
        >
          The most advanced sonography principles preparation platform. Interactive
          flashcards, physics pearls, and a realistic exam simulator — all designed by
          certified sonographers.
        </p>

        {/* CTAs */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20 transition-all duration-700"
          style={{ opacity: phase >= 4 ? 1 : 0, transform: phase >= 4 ? "translateY(0)" : "translateY(14px)", transitionDelay: "100ms" }}
        >
          <Link
            href="/demo"
            className="group inline-flex items-center gap-3 px-8 py-4 bg-[#C8923A] text-[#06080E]
              font-mono text-[0.75rem] uppercase tracking-[0.14em] font-bold
              hover:bg-[#E8AA55] transition-colors duration-300 relative overflow-hidden"
          >
            <Play className="w-3.5 h-3.5" />
            <span className="relative z-10">Try Free Demo</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
          <Link
            href="/auth/signin"
            className="group inline-flex items-center gap-3 px-8 py-4
              border border-[#EDE8E0]/16 text-[#EDE8E0]
              font-mono text-[0.75rem] uppercase tracking-[0.14em]
              hover:border-[#EDE8E0]/32 hover:bg-[#EDE8E0]/[0.04] transition-all duration-300"
          >
            Get Full Access
            <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </div>

        {/* Stats strip */}
        <div
          className="transition-all duration-700"
          style={{ opacity: phase >= 4 ? 1 : 0, transform: phase >= 4 ? "translateY(0)" : "translateY(14px)", transitionDelay: "200ms" }}
        >
          <HeroStats active={phase >= 4} />
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-7 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2.5 pointer-events-none">
        <span className="font-mono text-[0.58rem] uppercase tracking-[0.3em] text-[#2E2C2A]">Scroll</span>
        <div className="w-px h-9 bg-gradient-to-b from-[#C8923A]/50 to-transparent animate-pulse" />
      </div>
    </section>
  );
}

// ─── Products ─────────────────────────────────────────────────────────────────

const PRODUCTS = [
  {
    id: "flashcards", code: "SP·001",
    name: "SPI Flashcards", price: "$29", period: "90d",
    description: "2,400+ adaptive flashcards spanning every SPI domain. Spaced repetition algorithm calibrates to your individual performance curve.",
    icon: Zap,
    features: ["2,400+ cards", "Spaced repetition", "Progress tracking", "Mobile-optimized"],
    highlight: false,
  },
  {
    id: "physics", code: "SP·002",
    name: "Physics Pearls", price: "$9", period: "90d",
    description: "150+ high-yield physics pearls. Rapid-reference format for targeted review. Covers Doppler, attenuation, artifacts, and more.",
    icon: BookOpen,
    features: ["150+ pearls", "Quick reference", "Topic-organized", "Exam-focused"],
    highlight: false,
  },
  {
    id: "simulator", code: "SP·003",
    name: "Exam Simulator", price: "$49", period: "90d",
    description: "Full-length simulation: 170 questions, strict ARDMS timing, domain breakdown analytics, and performance prediction scoring.",
    icon: GraduationCap,
    features: ["170 questions", "Timed mode", "Performance analytics", "Domain breakdown"],
    highlight: true,
  },
  {
    id: "notes", code: "SP·004",
    name: "Study Notes", price: "$39", period: "90d",
    description: "Comprehensive notes authored by certified sonographers. 300+ pages of curated, diagram-rich clinical content. Fully searchable.",
    icon: FileText,
    features: ["300+ pages", "Certified authors", "Diagram-rich", "Searchable"],
    highlight: false,
  },
  {
    id: "bundle", code: "SP·005",
    name: "Premium Bundle", price: "$99", period: "90d",
    description: "All four instruments in a single clinical suite. Complete preparation, maximum efficiency, minimum friction. Save $27.",
    icon: Crown,
    features: ["All products", "Save $27", "Priority support", "Study planner"],
    highlight: true,
    badge: "Best Value",
  },
];

function ProductCard({
  product,
  index,
}: {
  product: (typeof PRODUCTS)[0];
  index: number;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const { ref: inViewRef, inView } = useInView();
  const [hovered, setHovered] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0, px: 50, py: 50 });
  const Icon = product.icon;

  const setRefs = useCallback(
    (el: HTMLDivElement | null) => {
      (cardRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
      (inViewRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
    },
    [inViewRef]
  );

  const onMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const cx = (e.clientX - rect.left) / rect.width;
    const cy = (e.clientY - rect.top) / rect.height;
    setTilt({ x: (cy - 0.5) * -9, y: (cx - 0.5) * 9, px: cx * 100, py: cy * 100 });
  }, []);

  const onLeave = useCallback(() => {
    setHovered(false);
    setTilt({ x: 0, y: 0, px: 50, py: 50 });
  }, []);

  return (
    <div
      ref={setRefs}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={onLeave}
      onMouseMove={onMove}
      className="relative overflow-hidden cursor-pointer group"
      style={{
        background: "#0C0F18",
        border: product.highlight
          ? "1px solid rgba(200,146,58,0.28)"
          : "1px solid rgba(237,232,224,0.07)",
        opacity: inView ? 1 : 0,
        transform: `perspective(1100px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) translateY(${inView ? "0" : "28px"})`,
        transition: `opacity 0.65s ${index * 80}ms ease, transform 0.65s ${index * 80}ms ease`,
        willChange: "transform, opacity",
      }}
    >
      {/* Specular sheen */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: hovered ? 1 : 0,
          background: `radial-gradient(circle at ${tilt.px}% ${tilt.py}%, rgba(200,146,58,0.07) 0%, transparent 55%)`,
          transition: "opacity 0.2s",
        }}
      />

      {/* Scanline texture on hover */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: hovered ? 1 : 0,
          backgroundImage:
            "repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(200,146,58,0.013) 3px, rgba(200,146,58,0.013) 4px)",
          transition: "opacity 0.3s",
        }}
      />

      {/* Top accent bar (highlighted only) */}
      {product.highlight && (
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#C8923A] to-transparent opacity-70" />
      )}

      {/* Badge */}
      {"badge" in product && product.badge && (
        <div className="absolute top-4 right-4 z-10 px-2.5 py-1 bg-[#C8923A]/12 border border-[#C8923A]/28">
          <span className="font-mono text-[0.62rem] uppercase tracking-wider text-[#C8923A]">
            {product.badge}
          </span>
        </div>
      )}

      {/* Header */}
      <div className="p-6 pb-4 border-b border-[#EDE8E0]/[0.065]">
        <div className="flex items-start justify-between mb-5">
          <div
            className="w-9 h-9 flex items-center justify-center transition-colors duration-400"
            style={{
              border: "1px solid",
              borderColor: hovered
                ? product.highlight ? "rgba(200,146,58,0.5)" : "rgba(237,232,224,0.2)"
                : "rgba(237,232,224,0.09)",
            }}
          >
            <Icon
              className="w-4 h-4 transition-colors duration-400"
              style={{ color: hovered ? (product.highlight ? "#C8923A" : "#EDE8E0") : "#4A4542" }}
            />
          </div>
          <span className="font-mono text-[0.6rem] tracking-widest text-[#2E2C2A]">
            {product.code}
          </span>
        </div>
        <div className="flex items-baseline gap-2 mb-1">
          <span className="font-display text-[2rem] text-[#EDE8E0]">{product.price}</span>
          <span className="font-mono text-[0.62rem] uppercase tracking-wider text-[#3A3835]">
            /{product.period}
          </span>
        </div>
        <h3 className="font-display text-[1.15rem] text-[#EDE8E0]">{product.name}</h3>
      </div>

      {/* Body */}
      <div className="p-6">
        <p className="text-[0.84rem] text-[#857F79] leading-relaxed mb-5">
          {product.description}
        </p>

        {/* Spec list */}
        <div className="space-y-2.5 mb-7">
          {product.features.map((f) => (
            <div key={f} className="flex items-center gap-2.5">
              <div
                className="w-1 h-1 rounded-full flex-shrink-0"
                style={{ background: product.highlight ? "#C8923A" : "#3A3835" }}
              />
              <span className="font-mono text-[0.68rem] tracking-wide text-[#857F79]">{f}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <Link
          href="/products"
          className="flex items-center justify-between w-full px-4 py-3 font-mono text-[0.72rem] uppercase tracking-[0.11em] transition-all duration-300 group/btn"
          style={{
            background: product.highlight ? "#C8923A" : "transparent",
            color: product.highlight ? "#06080E" : "#857F79",
            border: product.highlight ? "none" : "1px solid rgba(237,232,224,0.12)",
          }}
          onMouseEnter={(e) => {
            if (!product.highlight) {
              (e.currentTarget as HTMLElement).style.borderColor = "rgba(237,232,224,0.25)";
              (e.currentTarget as HTMLElement).style.color = "#EDE8E0";
            } else {
              (e.currentTarget as HTMLElement).style.background = "#E8AA55";
            }
          }}
          onMouseLeave={(e) => {
            if (!product.highlight) {
              (e.currentTarget as HTMLElement).style.borderColor = "rgba(237,232,224,0.12)";
              (e.currentTarget as HTMLElement).style.color = "#857F79";
            } else {
              (e.currentTarget as HTMLElement).style.background = "#C8923A";
            }
          }}
        >
          Get Access
          <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover/btn:translate-x-1" />
        </Link>
      </div>
    </div>
  );
}

function Products() {
  const { ref, inView } = useInView();

  return (
    <section id="products" className="relative py-32 sm:py-40">
      <div className="max-w-7xl mx-auto px-8">
        {/* Section header */}
        <div
          ref={ref}
          className="mb-20 transition-all duration-700"
          style={{ opacity: inView ? 1 : 0, transform: inView ? "translateY(0)" : "translateY(20px)" }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-6 h-px bg-gradient-to-r from-[#C8923A]/60 to-transparent" />
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.26em] text-[#C8923A]">
              Clinical Instruments
            </span>
          </div>
          <h2 className="font-display font-semibold text-[#EDE8E0] leading-[0.95] tracking-tight">
            <span className="block text-[2.8rem] sm:text-[3.8rem] md:text-[4.6rem]">Complete</span>
            <span className="block text-[2.8rem] sm:text-[3.8rem] md:text-[4.6rem] font-light text-[#4A4542]">
              Preparation Suite
            </span>
          </h2>
          <p className="text-[0.9rem] text-[#857F79] max-w-[400px] leading-relaxed mt-5">
            Five precision instruments, each crafted by certified sonographers who know
            exactly what the SPI demands.
          </p>
        </div>

        {/* Grid: 3 + 2 */}
        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-px"
          style={{ background: "rgba(237,232,224,0.065)" }}
        >
          {PRODUCTS.slice(0, 3).map((p, i) => (
            <div key={p.id} style={{ background: "#06080E" }}>
              <ProductCard product={p} index={i} />
            </div>
          ))}
        </div>
        <div
          className="grid grid-cols-1 md:grid-cols-2 gap-px mt-px max-w-4xl mx-auto"
          style={{ background: "rgba(237,232,224,0.065)" }}
        >
          {PRODUCTS.slice(3).map((p, i) => (
            <div key={p.id} style={{ background: "#06080E" }}>
              <ProductCard product={p} index={i + 3} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Features ─────────────────────────────────────────────────────────────────

const FEATURES = [
  {
    code: "F·01", icon: Brain,
    title: "Spaced Repetition",
    metric: "2.3×", metricLabel: "Retention",
    description:
      "Algorithm surfaces cards at scientifically optimal intervals. Performance-adaptive — the system recalibrates every session to your actual weak points.",
  },
  {
    code: "F·02", icon: Target,
    title: "Domain Targeting",
    metric: "5", metricLabel: "Core Domains",
    description:
      "Every question, card, and pearl is mapped to SPI exam taxonomy. Focus study time with surgical precision on the exact domains where you need it.",
  },
  {
    code: "F·03", icon: TrendingUp,
    title: "Performance Analytics",
    metric: "98%", metricLabel: "Accuracy",
    description:
      "Real-time readiness index, domain breakdowns, and predicted pass probability. You always know exactly where you stand before exam day.",
  },
  {
    code: "F·04", icon: Clock,
    title: "Timed Simulation",
    metric: "170", metricLabel: "Questions",
    description:
      "Full-length ARDMS-calibrated exam simulator. Strict timing, authentic question distribution, immediate post-exam domain analysis.",
  },
  {
    code: "F·05", icon: Shield,
    title: "Certified Content",
    metric: "15+", metricLabel: "Expert Authors",
    description:
      "All materials written and reviewed by ARDMS-certified sonographers with 10+ years of clinical and examination experience. Not generic AI-generated content.",
  },
  {
    code: "F·06", icon: Award,
    title: "First-Attempt Guarantee",
    metric: "94%", metricLabel: "First-Attempt",
    description:
      "Complete our recommended study protocol and meet benchmark scores. We stand behind the methodology. 94% of students pass on their first attempt.",
  },
];

function FeatureRow({
  f,
  index,
}: {
  f: (typeof FEATURES)[0];
  index: number;
}) {
  const { ref, inView } = useInView(0.1);
  const [hovered, setHovered] = useState(false);
  const Icon = f.icon;

  return (
    <div
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex gap-5 sm:gap-8 py-6 sm:py-7 border-b border-[#EDE8E0]/[0.065] px-4 -mx-4 sm:px-6 sm:-mx-6 transition-all duration-500"
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? "translateX(0)" : "translateX(-20px)",
        transitionDelay: `${index * 75}ms`,
        background: hovered ? "rgba(200,146,58,0.025)" : "transparent",
      }}
    >
      {/* Code */}
      <div className="w-10 sm:w-12 flex-shrink-0 font-mono text-[0.62rem] text-[#2E2C2A] pt-1.5 hidden sm:block">
        {f.code}
      </div>

      {/* Icon */}
      <div
        className="w-8 h-8 flex-shrink-0 flex items-center justify-center mt-0.5 transition-all duration-400"
        style={{
          border: "1px solid",
          borderColor: hovered ? "rgba(200,146,58,0.4)" : "rgba(237,232,224,0.09)",
        }}
      >
        <Icon
          className="w-3.5 h-3.5 transition-colors duration-400"
          style={{ color: hovered ? "#C8923A" : "#3A3835" }}
        />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <h3 className="font-display text-[1.15rem] text-[#EDE8E0] mb-1.5">{f.title}</h3>
        <p className="text-[0.82rem] text-[#857F79] leading-relaxed max-w-xl">{f.description}</p>
      </div>

      {/* Metric */}
      <div className="text-right flex-shrink-0 ml-4 hidden sm:block">
        <div
          className="font-display text-[1.8rem] leading-none transition-colors duration-400"
          style={{ color: hovered ? "#E8AA55" : "#C8923A" }}
        >
          {f.metric}
        </div>
        <div className="font-mono text-[0.58rem] uppercase tracking-wider text-[#3A3835] mt-1">
          {f.metricLabel}
        </div>
      </div>
    </div>
  );
}

function Features() {
  const { ref, inView } = useInView();

  return (
    <section id="features" className="relative py-32 sm:py-40" style={{ background: "#090B13" }}>
      <div className="max-w-4xl mx-auto px-8 sm:px-14">
        <div
          ref={ref}
          className="mb-16 transition-all duration-700"
          style={{ opacity: inView ? 1 : 0, transform: inView ? "translateY(0)" : "translateY(20px)" }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-6 h-px bg-gradient-to-r from-[#C8923A]/60 to-transparent" />
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.26em] text-[#C8923A]">
              System Specifications
            </span>
          </div>
          <h2 className="font-display font-semibold leading-[0.95] tracking-tight">
            <span className="block text-[2.8rem] sm:text-[4rem] text-[#EDE8E0]">Precision</span>
            <span className="block text-[2.8rem] sm:text-[4rem] font-light text-[#4A4542]">Engineered</span>
          </h2>
        </div>

        {/* Manifest table */}
        <div className="border-t border-[#EDE8E0]/[0.065]">
          {FEATURES.map((f, i) => (
            <FeatureRow key={f.code} f={f} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Testimonials ─────────────────────────────────────────────────────────────

const TESTIMONIALS = [
  {
    quote:
      "SonoPrep changed everything for me. The physics pearls alone were worth the price — I finally understood Doppler principles after years of confusion. Passed on my first attempt.",
    author: "Sarah M.",
    role: "RDMS, Cardiac Sonographer",
    location: "Boston, MA",
    score: "680/700",
    initials: "SM",
    tag: "First Attempt",
  },
  {
    quote:
      "The exam simulator is incredibly realistic. By test day, I felt completely prepared because I had already practiced in an environment that felt identical to the real thing.",
    author: "James K.",
    role: "RVT, Vascular Specialist",
    location: "Houston, TX",
    score: "712/700",
    initials: "JK",
    tag: "Maximum Score",
  },
  {
    quote:
      "I tried three other prep platforms before finding SonoPrep. The quality of content here is unmatched. Every flashcard is clinically relevant and thoughtfully written.",
    author: "Elena R.",
    role: "RDMS, OB/GYN Sonographer",
    location: "Miami, FL",
    score: "695/700",
    initials: "ER",
    tag: "Platform Switch",
  },
];

function Testimonials() {
  const [active, setActive] = useState(1);
  const { ref, inView } = useInView();

  return (
    <section className="relative py-32 sm:py-40">
      <div className="max-w-6xl mx-auto px-8">
        {/* Header */}
        <div
          ref={ref}
          className="mb-16 transition-all duration-700"
          style={{ opacity: inView ? 1 : 0, transform: inView ? "translateY(0)" : "translateY(20px)" }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-6 h-px bg-gradient-to-r from-[#C8923A]/60 to-transparent" />
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.26em] text-[#C8923A]">
              Clinical Outcomes
            </span>
          </div>
          <h2 className="font-display font-semibold leading-[0.95] tracking-tight">
            <span className="block text-[2.8rem] sm:text-[4rem] text-[#EDE8E0]">Sonographers</span>
            <span className="block text-[2.8rem] sm:text-[4rem] font-light text-[#4A4542]">Who Passed</span>
          </h2>
        </div>

        {/* Contact sheet / light-table layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {TESTIMONIALS.map((t, i) => (
            <div
              key={i}
              onClick={() => setActive(i)}
              className="relative cursor-pointer transition-all duration-500 p-7"
              style={{
                border: "1px solid",
                borderColor: active === i ? "rgba(200,146,58,0.32)" : "rgba(237,232,224,0.07)",
                background: active === i ? "rgba(12,10,20,0.85)" : "rgba(10,13,18,0.4)",
                opacity: active === i ? 1 : 0.48,
                transform: active === i ? "translateY(-3px)" : "translateY(0)",
                boxShadow: active === i ? "0 8px 40px rgba(200,146,58,0.07)" : "none",
              }}
            >
              {/* Active top bar */}
              {active === i && (
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#C8923A] to-transparent" />
              )}

              {/* Tag + index */}
              <div className="flex items-center justify-between mb-5">
                <span className="font-mono text-[0.6rem] uppercase tracking-widest text-[#C8923A]/65">
                  {t.tag}
                </span>
                <span className="font-mono text-[0.6rem] text-[#2E2C2A]">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>

              {/* Quote glyph */}
              <div className="font-display text-[4rem] text-[#C8923A]/12 leading-none -mt-3 mb-1 select-none">
                "
              </div>

              {/* Quote text */}
              <p className="font-display italic text-[1.05rem] text-[#EDE8E0]/82 leading-[1.5] mb-6">
                {t.quote}
              </p>

              {/* Author row */}
              <div className="flex items-end justify-between border-t border-[#EDE8E0]/[0.065] pt-5">
                <div>
                  <div className="flex items-center gap-2.5 mb-1.5">
                    <div className="w-7 h-7 flex items-center justify-center bg-[#C8923A]/10 border border-[#C8923A]/22">
                      <span className="font-mono text-[0.58rem] text-[#C8923A]">{t.initials}</span>
                    </div>
                    <span className="font-mono text-[0.72rem] text-[#EDE8E0]">{t.author}</span>
                  </div>
                  <div className="font-mono text-[0.62rem] text-[#4A4542]">{t.role}</div>
                  <div className="font-mono text-[0.62rem] text-[#3A3835]">{t.location}</div>
                </div>
                <div className="text-right">
                  <div className="font-display text-[1.6rem] text-[#C8923A] leading-none">{t.score}</div>
                  <div className="font-mono text-[0.55rem] uppercase tracking-wider text-[#3A3835] mt-1">Score</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation dashes */}
        <div className="flex items-center justify-center gap-3 mt-8">
          {TESTIMONIALS.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className="transition-all duration-400"
              style={{
                width: active === i ? "32px" : "8px",
                height: "1.5px",
                background: active === i ? "#C8923A" : "#2E2C2A",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── CTA ──────────────────────────────────────────────────────────────────────

function CTASection() {
  const { ref, inView } = useInView(0.1);

  return (
    <section className="relative py-32 sm:py-40" style={{ background: "#090B13" }}>
      <div className="max-w-7xl mx-auto px-8">
        <div
          ref={ref}
          className="grid grid-cols-1 lg:grid-cols-2 overflow-hidden transition-all duration-1000"
          style={{ opacity: inView ? 1 : 0, transform: inView ? "translateY(0)" : "translateY(24px)" }}
        >
          {/* Left — dark editorial */}
          <div
            className="relative p-12 sm:p-16"
            style={{ border: "1px solid rgba(237,232,224,0.07)", background: "#0C0F18" }}
          >
            {/* Corner markers */}
            {[
              { t: "top-4 left-4", r: "0" },
              { t: "bottom-4 right-4", r: "180" },
            ].map(({ t, r }, i) => (
              <div key={i} className={`absolute ${t} opacity-[0.18]`} style={{ transform: `rotate(${r}deg)` }}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M0 6V0H6" stroke="#C8923A" strokeWidth="1.5" />
                </svg>
              </div>
            ))}

            <div className="flex items-center gap-3 mb-10">
              <div className="w-5 h-px bg-gradient-to-r from-[#C8923A]/60 to-transparent" />
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.26em] text-[#C8923A]">
                Begin Protocol
              </span>
            </div>

            <h2 className="font-display font-semibold leading-[0.95] tracking-tight mb-7">
              <span className="block text-[2.6rem] sm:text-[3.6rem] text-[#EDE8E0]">Ready to Pass</span>
              <span className="block text-[2.6rem] sm:text-[3.6rem] italic text-[#C8923A]">the SPI?</span>
            </h2>

            <p className="text-[0.88rem] text-[#857F79] leading-relaxed mb-10 max-w-sm">
              Join thousands of sonographers who passed on their first attempt. Free demo
              available — no commitment required.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mb-10">
              <Link
                href="/demo"
                className="group inline-flex items-center gap-3 px-7 py-4 bg-[#C8923A] text-[#06080E]
                  font-mono text-[0.73rem] uppercase tracking-[0.13em] font-bold
                  hover:bg-[#E8AA55] transition-colors duration-300"
              >
                Try Free Demo
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-300" />
              </Link>
              <Link
                href="/products"
                className="inline-flex items-center gap-3 px-7 py-4
                  border border-[#EDE8E0]/14 text-[#EDE8E0]
                  font-mono text-[0.73rem] uppercase tracking-[0.13em]
                  hover:border-[#EDE8E0]/28 transition-colors duration-300"
              >
                View Pricing
              </Link>
            </div>

            {/* Trust signals */}
            <div className="flex flex-wrap items-center gap-6 pt-8 border-t border-[#EDE8E0]/[0.065]">
              {["No card required", "Instant access", "Cancel anytime"].map((s) => (
                <span
                  key={s}
                  className="flex items-center gap-2 font-mono text-[0.63rem] uppercase tracking-wider text-[#4A4542]"
                >
                  <Check className="w-3 h-3 text-[#C8923A]" />
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Right — amber panel */}
          <div
            className="relative p-12 sm:p-16 flex flex-col justify-between overflow-hidden"
            style={{ background: "#C8923A" }}
          >
            {/* Precision scanline texture */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage:
                  "repeating-linear-gradient(0deg, transparent, transparent 5px, rgba(0,0,0,0.06) 5px, rgba(0,0,0,0.06) 6px)",
              }}
            />
            {/* Grid overlay */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage:
                  "linear-gradient(rgba(0,0,0,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.06) 1px, transparent 1px)",
                backgroundSize: "36px 36px",
              }}
            />

            <div className="relative z-10">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.26em] text-[#06080E]/45 mb-8">
                Outcome Metrics
              </div>

              {[
                { value: "98%", label: "Student Pass Rate" },
                { value: "2,400+", label: "Practice Questions" },
                { value: "4.9 / 5", label: "Student Satisfaction" },
                { value: "$27", label: "Saved with Bundle" },
              ].map((m, i) => (
                <div
                  key={m.label}
                  className="flex items-baseline justify-between py-4"
                  style={{
                    borderBottom: "1px solid rgba(0,0,0,0.1)",
                  }}
                >
                  <span className="font-mono text-[0.72rem] uppercase tracking-wider text-[#06080E]/55">
                    {m.label}
                  </span>
                  <span className="font-display text-[1.9rem] text-[#06080E] leading-none">{m.value}</span>
                </div>
              ))}
            </div>

            {/* Stamp */}
            <div className="relative z-10 mt-8">
              <div
                className="inline-flex items-center gap-2 px-4 py-2"
                style={{ border: "2px solid rgba(0,0,0,0.18)" }}
              >
                <Activity className="w-3 h-3 text-[#06080E]/45" />
                <span className="font-mono text-[0.63rem] uppercase tracking-[0.2em] text-[#06080E]/45">
                  ARDMS-Aligned Content
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────

const FOOTER_COLS = [
  {
    title: "Products",
    links: [
      { name: "SPI Flashcards", href: "/products" },
      { name: "Physics Pearls", href: "/products" },
      { name: "Exam Simulator", href: "/products" },
      { name: "Study Notes", href: "/products" },
      { name: "Premium Bundle", href: "/products" },
    ],
  },
  {
    title: "Resources",
    links: [
      { name: "Free Demo", href: "/demo" },
      { name: "Dashboard", href: "/dashboard" },
      { name: "Blog", href: "/blog" },
      { name: "FAQ", href: "/faq" },
    ],
  },
  {
    title: "Company",
    links: [
      { name: "About", href: "/about" },
      { name: "Privacy", href: "/privacy" },
      { name: "Terms", href: "/terms" },
      { name: "Contact", href: "/about" },
    ],
  },
];

function Footer() {
  return (
    <footer className="border-t border-[#EDE8E0]/[0.065] py-16">
      <div className="max-w-7xl mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <Link href="/" className="inline-flex items-center gap-2.5 mb-5">
              <div
                className="w-7 h-7 flex items-center justify-center"
                style={{ border: "1px solid rgba(200,146,58,0.28)" }}
              >
                <Activity className="w-3.5 h-3.5 text-[#C8923A]" />
              </div>
              <span className="font-display text-[1.1rem] text-[#EDE8E0]">
                Sono<span className="text-[#C8923A]">Prep</span>
              </span>
            </Link>
            <p className="font-mono text-[0.7rem] text-[#3A3835] leading-relaxed">
              Built by sonographers, for sonographers. Pass the SPI — first attempt.
            </p>
          </div>

          {/* Columns */}
          {FOOTER_COLS.map((col) => (
            <div key={col.title}>
              <div className="font-mono text-[0.62rem] uppercase tracking-[0.22em] text-[#3A3835] mb-5">
                {col.title}
              </div>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l.name}>
                    <Link
                      href={l.href}
                      className="font-mono text-[0.72rem] text-[#857F79] hover:text-[#EDE8E0] transition-colors duration-200"
                    >
                      {l.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div
          className="pt-8 border-t border-[#EDE8E0]/[0.065] flex flex-col sm:flex-row items-center justify-between gap-3"
        >
          <span className="font-mono text-[0.62rem] text-[#2E2C2A]">
            © 2025 SonoPrep. All rights reserved.
          </span>
          <span className="font-mono text-[0.62rem] text-[#2E2C2A] text-center sm:text-right">
            ARDMS® is a registered trademark. SonoPrep is not affiliated with ARDMS.
          </span>
        </div>
      </div>
    </footer>
  );
}

// ─── Export ───────────────────────────────────────────────────────────────────

export function HomePageClient() {
  return (
    <div className="min-h-screen" style={{ background: "#06080E", fontFamily: "Inter, system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap');

        .font-display {
          font-family: 'Cormorant Garamond', 'Times New Roman', Georgia, serif;
          font-feature-settings: 'kern' 1, 'liga' 1;
        }
        .font-mono {
          font-family: 'Space Mono', 'Courier New', monospace;
        }

        *, *::before, *::after {
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        ::selection {
          background: rgba(200, 146, 58, 0.22);
          color: #EDE8E0;
        }

        html {
          scroll-behavior: smooth;
        }

        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-track { background: #06080E; }
        ::-webkit-scrollbar-thumb { background: #C8923A; border-radius: 0; }
        ::-webkit-scrollbar-thumb:hover { background: #E8AA55; }

        @keyframes pulse-amber {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }
        .animate-pulse { animation: pulse-amber 2.4s ease-in-out infinite; }
      `}</style>

      <Navigation />
      <main>
        <Hero />
        <Products />
        <Features />
        <Testimonials />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
