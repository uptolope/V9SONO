#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# SonoPrep V9 — Deploy to GitHub (uptolope/V9SONO) + Vercel
# Run: bash deploy.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
GITHUB_REPO="git@github.com:uptolope/V9SONO.git"
GITHUB_HTTPS="https://github.com/uptolope/V9SONO.git"

echo ""
echo "  ┌─────────────────────────────────────────────┐"
echo "  │   SonoPrep V9 · Precision Deploy Script     │"
echo "  └─────────────────────────────────────────────┘"
echo ""

# ── 1. Install deps ──────────────────────────────────────────────────────────
echo "▸ Installing dependencies..."
cd "$PROJECT_DIR"
npm install --legacy-peer-deps

# ── 2. Build check ───────────────────────────────────────────────────────────
echo "▸ Verifying build..."
npm run build

# ── 3. Git init + push to GitHub ─────────────────────────────────────────────
echo "▸ Initializing git..."
git init -b main
git add -A
git commit -m "feat: SonoPrep V9 — Cinematic precision instrument upgrade

- Amber-sole accent system (no teal), surgical bone-white typography
- B-mode ultrasound canvas: sweep scanline, tissue simulation, focal zone
- Cormorant Garamond display + Space Mono data readouts
- 3D card tilt with specular sheen and spring physics
- Spring counter animation with overshoot on hero stats
- Spec-sheet feature manifest table (instrument aesthetic)
- Light-table contact print testimonials
- Split-composition amber CTA panel with scan-line texture
- Live clock readout in navigation
- Mouse crosshair with depth annotation on canvas
- Precision corner bracket decorators throughout
- Thin amber scrollbar, custom ::selection color"

echo ""
echo "▸ Pushing to GitHub..."
echo "  Attempting SSH: $GITHUB_REPO"

if git remote get-url origin 2>/dev/null; then
  git remote set-url origin "$GITHUB_REPO"
else
  git remote add origin "$GITHUB_REPO"
fi

if git push -u origin main --force 2>/dev/null; then
  echo "  ✓ Pushed via SSH"
else
  echo "  SSH failed — retrying via HTTPS..."
  git remote set-url origin "$GITHUB_HTTPS"
  git push -u origin main --force
  echo "  ✓ Pushed via HTTPS"
fi

# ── 4. Vercel deploy ─────────────────────────────────────────────────────────
echo ""
echo "▸ Deploying to Vercel..."

# Install Vercel CLI if not present
if ! command -v vercel &>/dev/null; then
  npm install -g vercel
fi

# Deploy (non-interactive: link to existing project)
vercel --prod \
  --yes \
  --name "v9-sono-bfkp" \
  --scope "uptolopes-projects" \
  2>&1

echo ""
echo "  ┌─────────────────────────────────────────────┐"
echo "  │   ✓ Deploy complete                         │"
echo "  │                                             │"
echo "  │   GitHub: github.com/uptolope/V9SONO        │"
echo "  │   Vercel: v9-sono-bfkp...vercel.app         │"
echo "  └─────────────────────────────────────────────┘"
echo ""
